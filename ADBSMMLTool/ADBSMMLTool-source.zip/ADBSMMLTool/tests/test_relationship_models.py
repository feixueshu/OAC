import copy,json,importlib.util
from pathlib import Path
import pytest
from smml_tool.core import ToolError,model_config,initial_review,validate_metadata
from smml_tool.generator import build_model,changes
from smml_tool.relationships import classify_measures
from smml_tool.bundle import save_bundle,load_bundle
from smml_tool import workbook
ROOT=Path(__file__).resolve().parents[1]


def col(name,kind='NUMBER',p=10,s=0):return dict(name=name,data_type=kind,precision=p,scale=s,nullable=False,comment={'ID':'番号','COUNTRY_ID':'国番号','CUST_ID':'顧客番号','AMOUNT':'金額','QTY':'数量','NAME':'名称'}.get(name,name),length=20 if kind=='VARCHAR2' else 0)
def key(name,columns):return dict(name=name,type='P',columns=columns,status='DISABLED',validated='NOT VALIDATED',rely=True)
def fk(name,column,target,target_column='ID'):return dict(name=name,columns=[column],target_owner='S',target_table=target,target_columns=[target_column],status='DISABLED',validated='NOT VALIDATED',rely=True)
def source():return dict(format_version=1,source='unit-test',tables=[
 dict(owner='S',name='COUNTRIES',comment='国',columns=[col('ID'),col('NAME','VARCHAR2')],key_constraints=[key('COUNTRY_PK',['ID'])],primary_key=[],foreign_keys=[]),
 dict(owner='S',name='CUSTOMERS',comment='顧客',columns=[col('ID'),col('COUNTRY_ID'),col('NAME','VARCHAR2')],key_constraints=[key('CUST_PK',['ID'])],primary_key=[],foreign_keys=[fk('CUST_COUNTRY_FK','COUNTRY_ID','COUNTRIES')]),
 dict(owner='S',name='SALES',comment='売上',columns=[col('ID'),col('CUST_ID'),col('AMOUNT',p=10,s=2),col('QTY',p=10,s=2)],key_constraints=[],primary_key=[],foreign_keys=[fk('SALES_CUST_FK','CUST_ID','CUSTOMERS')])])
def settings():return dict(oac_connection="'system'.'ADW_SMML'",strategy='foreign_key_star',constraint_policy='validated_or_rely')
def physical(m):return {p:d for p,d in m['files'].items() if p.startswith('physical/')}
def logical(m):return [(p,d['logicalTable']) for p,d in m['files'].items() if 'logicalTable' in d]


def test_relationships_snowflake_and_decimal_measures():
 m=build_model(source(),settings())
 assert m['stats']['physical_foreign_keys']==2 and m['stats']['logical_foreign_key_joins']==3
 assert m['stats']['measure_columns']==2 and m['stats']['subject_areas']==3
 sales=[t for p,t in logical(m) if 'S.SALES' in p and t['type']=='FACT'][0]
 assert {c['name']:c['aggregation']['rule'] for c in sales['logicalColumns']}=={'金額':'SUM','数量':'SUM','行数（自動生成）':'SUM'}
 for p,t in logical(m):
  if t['type']=='DIMENSION':assert not any(c.get('aggregation') or c['name'] in {'金額','数量'} for c in t['logicalColumns'])
 assert len(sales['joins'])==2
 customer=[t for p,t in logical(m) if 'S.SALES' in p and t['name']=='CUSTOMERS'][0]
 assert customer['joins'][0]['rightTable'].endswith('.COUNTRIES')
 sale_physical=next(d['physicalTable'] for p,d in physical(m).items() if p.endswith('/SALES.json'))
 assert sale_physical['joins'][0]['joinExpression']['expressionTemplate']=='%1 = %2'
 assert all(v.startswith('physicalColumn:') for v in sale_physical['joins'][0]['joinExpression']['expressionObjects'])
 assert m['validation']['reference_integrity']=='passed'
 assert any('DISABLED' in warning for warning in m['warnings'])
 assert any(r[5]=='NUMBER(10,2)' for r in m['review'])


def test_measure_overrides_and_decimal_keys_stay_attributes():
 s=source();s['tables'][1]['columns'][0]['scale']=2
 cfg=dict(settings(),measures={'S.SALES':{'AMOUNT':'AVG'}})
 m=build_model(s,cfg)
 assert m['stats']['measure_columns']==2
 assert next(x for x in m['measure_classification'] if x['column']=='AMOUNT')['rule']=='AVG'
 assert not any(x['table']=='S.CUSTOMERS' and x['column']=='ID' for x in m['measure_classification'])
 with pytest.raises(ToolError):build_model(s,dict(settings(),measures={'S.CUSTOMERS':{'ID':'SUM'}}))


def test_validated_only_and_disabled_nonrely_do_not_silently_assume_integrity():
 s=source()
 assert build_model(s,dict(settings(),constraint_policy='validated_only'))['stats']['physical_foreign_keys']==0
 for t in s['tables']:
  for f in t['foreign_keys']:f['rely']=False
 assert build_model(s,settings())['stats']['physical_foreign_keys']==0
 for t in s['tables']:
  for k in t['key_constraints']:k.update(status='ENABLED',validated='VALIDATED')
  for f in t['foreign_keys']:f.update(status='ENABLED',validated='VALIDATED')
 assert build_model(s,dict(settings(),constraint_policy='validated_only'))['stats']['physical_foreign_keys']==2


def test_nullable_fk_uses_outer_join():
 s=source();s['tables'][2]['columns'][1]['nullable']=True;m=build_model(s,settings())
 assert next(e for e in m['relationships'] if e['source']=='S.SALES')['join_type']=='LEFT_OUTER'


def test_key_exclusion_disconnects_only_logical_join_and_rename_propagates():
 before=build_model(source(),settings());rows=copy.deepcopy(before['review'])
 for r in rows:
  if r[2]=='S.SALES' and r[3]=='CUST_ID':r[7]='TRUTH'
  if r[2]=='S.CUSTOMERS':r[1]='顧客変更'
 after=build_model(source(),settings(),rows)
 assert physical(before)==physical(after) and changes(before,after)['physical_layer_unchanged']
 assert after['stats']['logical_foreign_key_joins']==1
 assert any('TRUE' in w for w in after['warnings'])
 assert any(t['name']=='顧客変更' for p,t in logical(after))
 assert all(t['name']!='顧客変更' for p,t in logical(after) if 'S.SALES' in p)
 restored=copy.deepcopy(rows)
 for i,r in enumerate(restored):r[:]=before['review'][i]
 assert build_model(source(),settings(),restored)['files']==before['files']


def test_all_excluded_preserves_physical_fk_graph():
 m=build_model(source(),settings());rows=copy.deepcopy(m['review'])
 for r in rows:r[7]='TRUTH'
 new=build_model(source(),settings(),rows)
 assert physical(new)==physical(m) and all(p.startswith('physical/') for p in new['files'])
 assert new['stats']['subject_areas']==0 and new['stats']['measure_columns']==0


def test_composite_fk_expression_has_all_pairs():
 s=source();country=s['tables'][0];customer=s['tables'][1]
 country['columns'].append(col('ZONE'));country['key_constraints'][0]['columns'].append('ZONE')
 customer['columns'].append(col('ZONE'));customer['foreign_keys'][0]['columns'].append('ZONE');customer['foreign_keys'][0]['target_columns'].append('ZONE')
 m=build_model(s,settings());p=next(d['physicalTable'] for p,d in m['files'].items() if p.endswith('/CUSTOMERS.json'))
 assert p['joins'][0]['joinExpression']['expressionTemplate']=='%1 = %2 AND %3 = %4'
 assert len(p['joins'][0]['joinExpression']['expressionObjects'])==4


@pytest.mark.parametrize('mutation',['self','cycle','same_parent_twice','bad_columns','missing_key_column'])
def test_unsupported_or_malformed_relationships_stop(mutation):
 s=source()
 if mutation=='self':s['tables'][1]['foreign_keys'].append(fk('SELF_FK','ID','CUSTOMERS'))
 elif mutation=='cycle':s['tables'][0]['foreign_keys'].append(fk('CYCLE','ID','CUSTOMERS'))
 elif mutation=='same_parent_twice':s['tables'][2]['foreign_keys'].append(fk('SECOND','ID','CUSTOMERS'))
 elif mutation=='bad_columns':s['tables'][2]['foreign_keys'][0]['columns']=['GHOST']
 else:s['tables'][0]['key_constraints'][0]['columns']=['GHOST']
 with pytest.raises(ToolError):build_model(s,settings())


def test_missing_target_is_reported_not_guessed():
 s=source();s['tables']=s['tables'][1:];m=build_model(s,settings())
 assert m['stats']['physical_foreign_keys']==1 and any('対象表一覧の外' in w for w in m['warnings'])


def test_extra_options_do_not_change_legacy_config_fingerprints():
 cfg=model_config({'oac_connection':"'system'.'TEST'",'strategy':'single_table_star'})
 assert 'auto_decimal_measures' not in cfg and 'constraint_policy' not in cfg
 assert build_model(source(),dict(oac_connection="'system'.'TEST'",strategy='single_table_star'))['stats']['subject_areas']==3


def test_version_reports_are_verified_but_never_in_smml_zip(tmp_path,monkeypatch):
 monkeypatch.setattr(workbook,'artifact_runtime',lambda:None)
 m=build_model(source(),settings());save_bundle(m,tmp_path/'base')
 assert load_bundle(tmp_path/'base')['files']==m['files']
 assert (tmp_path/'base/relationships.json').is_file() and (tmp_path/'base/measure-classification.json').is_file()
 import zipfile
 with zipfile.ZipFile(tmp_path/'base/model.zip') as z:assert all(n.startswith(('physical/','logical/','presentation/')) for n in z.namelist())


def test_decimal_only_table_gets_hidden_technical_member_not_attribute_measure():
 s=dict(format_version=1,tables=[dict(owner='S',name='ONLY_MEASURES',columns=[col('AMOUNT',s=2)],primary_key=[],foreign_keys=[])])
 m=build_model(s,settings());dims=[t for p,t in logical(m) if t['type']=='DIMENSION']
 assert dims[0]['logicalColumns'][0]['name']=='技術メンバー'
 p=next(d['presentationTable'] for d in m['files'].values() if 'presentationTable' in d)
 assert '技術メンバー' not in {c['name'] for c in p['presentationColumns']} and m['stats']['measure_columns']==1


def test_fk_model_names_do_not_use_long_or_duplicate_english_table_descriptions():
 m=build_model(source(),settings())
 assert {r[1] for r in m['review']}=={'COUNTRIES','CUSTOMERS','SALES'}
 assert next(d['physicalTable'] for p,d in m['files'].items() if p.endswith('/COUNTRIES.json'))['description']=='国'


def test_collector_keeps_rely_keys_separate_from_enforced_primary_keys():
 from smml_tool.adb import key_metadata
 raw=[dict(name='PK',type='P',column='ID',position=1,status='DISABLED',validated='NOT VALIDATED',rely='RELY')]
 data=key_metadata(raw)
 assert data['primary_key']==[] and data['key_constraints'][0]['rely'] is True
 raw[0].update(status='ENABLED',validated='VALIDATED',rely=None)
 assert key_metadata(raw)['primary_key']==['ID']


def test_collector_preserves_composite_fk_position_order():
 from smml_tool.adb import key_metadata
 rows=[dict(name='FK',type='R',column=a,position=i,target_owner='S',target_table='P',target_column=b,status='DISABLED',validated='NOT VALIDATED',rely='RELY') for i,a,b in [(2,'B','Y'),(1,'A','X')]]
 f=key_metadata(rows)['foreign_keys'][0]
 assert f['columns']==['A','B'] and f['target_columns']==['X','Y'] and f['rely'] is True
