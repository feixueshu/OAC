import copy
import pytest

from smml_tool.core import model_config
from smml_tool.generator import build_model


def source():
    return dict(format_version=1, source='test', tables=[dict(owner='S', name='T', comment='テスト',
        columns=[dict(name='CODE',data_type='CHAR',length=4,comment='コード'),
                 dict(name='VALUE',data_type='NUMBER',comment='金額')],primary_key=[],foreign_keys=[])])


def settings():
    return dict(strategy='single_table_star', oac_connection="'system'.'TEST'")


def table_documents(model):
    return [d['logicalTable'] for d in model['files'].values() if 'logicalTable' in d]


def test_star_has_two_projections_and_one_physical_source():
    model=build_model(source(),settings())
    dimension,fact=sorted(table_documents(model),key=lambda t:t['type'])
    assert dimension['type']=='DIMENSION' and fact['type']=='FACT'
    assert dimension['primaryKey']==['コード','金額']
    assert all('aggregation' not in c for c in dimension['logicalColumns'])
    assert len(fact['logicalColumns'])==1 and fact['logicalColumns'][0]['aggregation']=={'rule':'SUM'}
    assert fact['joins'][0]['cardinality']=='MANY_TO_ONE'
    assert dimension['logicalTableSources']==fact['logicalTableSources']
    assert model['stats']['source_columns']==2 and model['stats']['subject_areas']==1
    subject=next(d['subjectArea'] for d in model['files'].values() if 'subjectArea' in d)
    assert fact['name'] in subject['implicitFactColumn']


def test_star_preserves_physical_layer_and_legacy_behavior():
    new=build_model(source(),settings())
    old=build_model(source(),dict(settings(),strategy='single_table'))
    assert {p:d for p,d in new['files'].items() if p.startswith('physical/')}=={p:d for p,d in old['files'].items() if p.startswith('physical/')}
    assert len(table_documents(old))==1 and table_documents(old)[0]['type']=='FACT'


def test_star_delete_updates_attribute_tuple_and_leaves_physical():
    before=build_model(source(),settings());rows=copy.deepcopy(before['review']);rows[0][7]='TRUTH'
    after=build_model(source(),settings(),rows)
    dim=next(t for t in table_documents(after) if t['type']=='DIMENSION')
    assert dim['primaryKey']==['金額']
    assert 'コード' not in [c['name'] for c in dim['logicalColumns']]
    assert {p:d for p,d in before['files'].items() if p.startswith('physical/')}=={p:d for p,d in after['files'].items() if p.startswith('physical/')}


def test_star_measures_are_explicit_and_presented_from_fact():
    model=build_model(source(),dict(settings(),measures={'S.T':{'VALUE':'SUM'}}))
    fact=next(t for t in table_documents(model) if t['type']=='FACT')
    assert len(fact['logicalColumns'])==2
    presentation=next(d['presentationTable'] for d in model['files'].values() if 'presentationTable' in d)
    col=next(c for c in presentation['presentationColumns'] if c['name']=='金額')
    assert fact['name'] in col['sourceLogicalColumn']


def test_star_all_deleted_has_no_semantic_objects():
    m=build_model(source(),settings());rows=copy.deepcopy(m['review'])
    for r in rows:r[7]='TRUTH'
    out=build_model(source(),settings(),rows)
    assert all(p.startswith('physical/') for p in out['files'])
    assert out['stats']['subject_areas']==0
