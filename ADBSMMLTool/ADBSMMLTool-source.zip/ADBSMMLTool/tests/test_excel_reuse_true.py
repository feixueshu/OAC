"""Reuse compatible eight-column Excel by physical keys, not generation hashes."""
import copy
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import pytest
from smml_tool import workbook
from smml_tool.core import ToolError,normalize_delete_flag
from smml_tool.generator import build_model
from smml_tool.bundle import save_bundle,apply_workbook
from test_relationship_models import source,settings
from test_excel_false_compat import change_fixture_cell


@pytest.fixture
def reusable_book(tmp_path,monkeypatch):
    monkeypatch.setattr(workbook,'artifact_runtime',lambda:None)
    m=build_model(source(),settings());save_bundle(m,tmp_path/'base')
    return m,tmp_path/'base/review.xlsx'


def add_obsolete_binding_sheet(p):
    """Adversarial legacy fixture only: metadata deliberately belongs to another batch."""
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    rel='http://schemas.openxmlformats.org/package/2006/relationships'
    docrel='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    content='http://schemas.openxmlformats.org/package/2006/content-types'
    with ZipFile(p) as z:parts={n:z.read(n) for n in z.namelist()}
    root=ET.fromstring(parts['xl/workbook.xml'])
    ET.SubElement(root.find(f'{{{ns}}}sheets'),f'{{{ns}}}sheet',name='管理情報',sheetId='3',state='veryHidden',attrib={f'{{{docrel}}}id':'rIdOldBinding'})
    parts['xl/workbook.xml']=ET.tostring(root)
    root=ET.fromstring(parts['xl/_rels/workbook.xml.rels'])
    ET.SubElement(root,f'{{{rel}}}Relationship',Id='rIdOldBinding',Type=docrel+'/worksheet',Target='/xl/worksheets/legacy.xml')
    parts['xl/_rels/workbook.xml.rels']=ET.tostring(root)
    root=ET.fromstring(parts['[Content_Types].xml'])
    ET.SubElement(root,f'{{{content}}}Override',PartName='/xl/worksheets/legacy.xml',ContentType='application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml')
    parts['[Content_Types].xml']=ET.tostring(root)
    root=ET.Element(f'{{{ns}}}worksheet');data=ET.SubElement(root,f'{{{ns}}}sheetData');row=ET.SubElement(data,f'{{{ns}}}row',r='1')
    for cell,value in [('A1','baseline_sha256'),('B1','obsolete-batch-not-current')]:
        c=ET.SubElement(row,f'{{{ns}}}c',r=cell,t='inlineStr');ET.SubElement(ET.SubElement(c,f'{{{ns}}}is'),f'{{{ns}}}t').text=value
    parts['xl/worksheets/legacy.xml']=ET.tostring(root)
    with ZipFile(p,'w') as z:
        for name,body in parts.items():z.writestr(name,body)


@pytest.mark.parametrize('value,expected',[(True,'TRUE'),(False,'FALSE'),('TRUE','TRUE'),('true','TRUE'),(' true ','TRUE'),('FALSE','FALSE'),('false','FALSE'),('FALSE ','FALSE'),('TRUTH','TRUE'),('truth','TRUE')])
def test_canonical_flags(value,expected):assert normalize_delete_flag(value)==expected


@pytest.mark.parametrize('kind,value',[('b','1'),('inlineStr','TRUE'),('inlineStr','true'),('inlineStr','TRUTH')])
def test_standard_and_legacy_delete_flags_match(reusable_book,tmp_path,kind,value):
    m,original=reusable_book;p=tmp_path/'edited.xlsx';change_fixture_cell(original,p,'H2',kind,value)
    rows=workbook.read_review(p,m)
    assert rows[0][7]=='TRUE'
    after=build_model(m['metadata'],m['config'],rows)
    assert after['stats']['deleted_semantic_columns']==1
    assert {p:d for p,d in after['files'].items() if p.startswith('physical/')}=={p:d for p,d in m['files'].items() if p.startswith('physical/')}


def test_obsolete_generation_metadata_no_longer_blocks(reusable_book):
    m,p=reusable_book;add_obsolete_binding_sheet(p)
    other=copy.deepcopy(m);other['metadata']['captured_at']='a-new-generation';other['config']['database_name']='NEW_LOGICAL_DB_LABEL'
    assert workbook.read_review(p,other)==m['review']


def test_excel_row_order_is_not_identity(reusable_book,tmp_path):
    m,p=reusable_book
    # Reverse source order in current metadata; matching still uses C/D identifiers.
    other=copy.deepcopy(m);other['metadata']['tables'].reverse()
    assert workbook.read_review(p,other)==m['review']


@pytest.mark.parametrize('cell,value,match',[('C2','OTHER.COUNTRIES','未知/重複'),('D2','UNKNOWN_COLUMN','未知/重複'),('F2','VARCHAR2','属性/サイズ'),('G2','99','属性/サイズ')])
def test_unrelated_or_changed_definitions_rejected(reusable_book,tmp_path,cell,value,match):
    m,p=reusable_book;bad=tmp_path/'bad.xlsx';change_fixture_cell(p,bad,cell,'inlineStr',value)
    with pytest.raises(ToolError,match=match):workbook.read_review(bad,m)


def test_row_omissions_are_not_interpreted_as_deletes(reusable_book,tmp_path):
    m,p=reusable_book;bad=tmp_path/'missing.xlsx'
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    with ZipFile(p) as z,ZipFile(bad,'w') as out:
        for entry in z.infolist():
            raw=z.read(entry.filename)
            if entry.filename=='xl/worksheets/sheet1.xml':
                root=ET.fromstring(raw);data=root.find(f'{{{ns}}}sheetData');data.remove(data.find(f'{{{ns}}}row[@r="2"]'));raw=ET.tostring(root)
            out.writestr(entry,raw)
    with pytest.raises(ToolError,match='欠落'):workbook.read_review(bad,m)


def test_new_template_and_instructions_are_true_false_only(reusable_book):
    m,p=reusable_book
    from openpyxl import load_workbook
    w=load_workbook(p)
    assert w.sheetnames==['テーブル一覧','使い方']
    rule=list(w['テーブル一覧'].data_validations.dataValidation)[0]
    assert rule.formula1=='"TRUE,FALSE"'
    assert 'TRUTH' not in str(list(w['使い方'].values))
    w.close()
