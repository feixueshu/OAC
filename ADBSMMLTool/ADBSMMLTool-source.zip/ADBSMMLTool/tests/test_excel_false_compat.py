"""Standard boolean TRUE/FALSE and historical TRUTH compatibility."""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import hashlib
import pytest
from openpyxl import load_workbook
from smml_tool import workbook
from smml_tool.bundle import save_bundle,load_bundle
from smml_tool.generator import build_model
from smml_tool.core import ToolError
from test_relationship_models import source,settings


def change_fixture_cell(source,target,cell,kind,value):
    """Write a deliberately malformed test ZIP, never a customer deliverable."""
    ns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    with ZipFile(source) as z,ZipFile(target,'w') as out:
        for item in z.infolist():
            content=z.read(item.filename)
            if item.filename=='xl/worksheets/sheet1.xml':
                root=ET.fromstring(content);node=root.find(f'.//{{{ns}}}c[@r="{cell}"]')
                assert node is not None
                for child in list(node):node.remove(child)
                node.set('t',kind)
                if kind=='inlineStr':ET.SubElement(ET.SubElement(node,f'{{{ns}}}is'),f'{{{ns}}}t').text=value
                else:ET.SubElement(node,f'{{{ns}}}v').text=value
                content=ET.tostring(root,encoding='utf-8',xml_declaration=True)
            out.writestr(item,content)


@pytest.fixture
def excel_base(tmp_path,monkeypatch):
    monkeypatch.setattr(workbook,'artifact_runtime',lambda:None)
    m=build_model(source(),settings());save_bundle(m,tmp_path/'base')
    return m,tmp_path/'base/review.xlsx'


def test_boolean_false_retains_column_and_does_not_modify_customer_file(excel_base,tmp_path):
    m,book=excel_base;p=tmp_path/'false.xlsx';change_fixture_cell(book,p,'H2','b','0')
    before=hashlib.sha256(p.read_bytes()).hexdigest()
    rows=workbook.read_review(p,m)
    assert rows==m['review'] and rows[0][7]=='FALSE'
    assert build_model(m['metadata'],m['config'],rows)['files']==m['files']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==before


@pytest.mark.parametrize('kind,value',[('n','0'),('n','1')])
def test_true_and_numeric_flags_are_not_promoted_to_deletion(excel_base,tmp_path,kind,value):
    m,book=excel_base;p=tmp_path/'invalid.xlsx';change_fixture_cell(book,p,'H2',kind,value)
    with pytest.raises(ToolError,match='TRUE / FALSE'):workbook.read_review(p,m)


def test_only_h_column_boolean_false_is_normalized(excel_base,tmp_path):
    m,book=excel_base;p=tmp_path/'alias.xlsx';change_fixture_cell(book,p,'E2','b','0')
    with pytest.raises(ToolError):workbook.read_review(p,m)


def test_literal_truth_still_explicitly_deletes(excel_base,tmp_path):
    m,book=excel_base;p=tmp_path/'delete.xlsx';change_fixture_cell(book,p,'H2','inlineStr','TRUTH')
    rows=workbook.read_review(p,m)
    result=build_model(m['metadata'],m['config'],rows)
    assert result['stats']['deleted_semantic_columns']==1


def test_portable_template_flags_use_text_format(excel_base):
    _,book=excel_base;w=load_workbook(book,read_only=True)
    assert all(c[0].number_format=='@' for c in w['テーブル一覧'].iter_rows(min_row=2,min_col=8,max_col=8))
    w.close()
