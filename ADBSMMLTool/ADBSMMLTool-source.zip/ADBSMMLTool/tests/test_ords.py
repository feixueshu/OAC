import copy
import io
import json
import urllib.error

import pytest

from smml_tool import ords
from smml_tool.adb import extract_configured
from smml_tool.core import ToolError

URL = 'https://example.oraclecloudapps.com/ords/admin/_/sql'


def config():
    return dict(transport='ords', ords_url=URL, schema='CaseOwner', tables=['CaseTable'], expected_database='TEST_DB')


def row():
    return dict(owner='CaseOwner', table_name='CaseTable', table_type='TABLE', table_comment='テスト表',
        column_name='ID', data_type='NUMBER', byte_length=22, char_length=0, char_used=None,
        data_precision=10, data_scale=0, nullable='N', column_comment='番号', column_id=1,
        database_name='TEST_DB', session_schema='ADMIN', container_name='TEST_DB', service_name='test_low',
        keys_json=json.dumps([dict(name='PK_T', type='P', column='ID', position=1, target_owner=None,
            target_table=None, target_column=None, status='ENABLED', validated='VALIDATED')]))


@pytest.mark.parametrize('url', [
    'http://example.com/ords/admin/_/sql', 'https://user:secret@example.com/ords/admin/_/sql',
    URL+'?password=secret', URL+'#token', 'https://example.com/not-sql',
    'https://example.com:8443/ords/admin/_/sql',
])
def test_endpoint_rejects_unsafe_url(url):
    with pytest.raises(ToolError, match='HTTPS'):
        ords._validate_endpoint(url)


def test_endpoint_and_redirect_guard():
    assert ords._validate_endpoint(URL) == URL
    with pytest.raises(ToolError, match='リダイレクト'):
        ords._NoRedirect().redirect_request(None, None, 302, '', {}, 'https://other.example')


def test_ords_snapshot_binds_and_pk(monkeypatch):
    seen = {}
    def query(endpoint, sql, binds, user, password):
        seen.update(endpoint=endpoint, sql=sql, binds=binds)
        return [row()]
    monkeypatch.setattr(ords, '_post_dictionary', query)
    out = extract_configured(config(), {'user':'ADMIN', 'password':'not-real'})
    assert out['source'] == 'adb_dictionary_read_only' and out['consistency'] == 'single_dictionary_select'
    assert out['transport'] == 'ords_rest_enabled_sql'
    assert out['tables'][0]['primary_key'] == ['ID']
    assert out['tables'][0]['columns'][0]['precision'] == 10
    assert 'CaseOwner' not in seen['sql'] and 'CaseTable' not in seen['sql']
    assert seen['binds'] == [dict(name='owner', data_type='VARCHAR2', value='CaseOwner'), dict(name='t0', data_type='VARCHAR2', value='CaseTable')]


@pytest.mark.parametrize('mutation', ['database', 'missing_table', 'out_of_scope', 'gap'])
def test_ords_rejects_wrong_or_partial_results(monkeypatch, mutation):
    cfg = config(); r = row()
    if mutation == 'database': r['database_name'] = 'WRONG_DB'
    if mutation == 'missing_table': cfg['tables'].append('Missing')
    if mutation == 'out_of_scope': r['owner'] = 'UNRELATED'
    if mutation == 'gap': r['column_id'] = 2
    monkeypatch.setattr(ords, '_post_dictionary', lambda *a: [r])
    with pytest.raises(ToolError):
        ords.extract_ords(cfg, {'user':'ADMIN','password':'not-real'})


def test_character_length_and_fk(monkeypatch):
    r = row(); r.update(data_type='VARCHAR2', char_length=12, char_used='C', byte_length=48,
        keys_json=json.dumps([dict(name='FK_T', type='R', column='ID', position=1, target_owner='REF',
            target_table='TARGET', target_column='CODE', status='ENABLED', validated='VALIDATED')]))
    monkeypatch.setattr(ords, '_post_dictionary', lambda *a: [r])
    out = ords.extract_ords(config(), {'user':'ADMIN','password':'not-real'})['tables'][0]
    assert out['columns'][0]['length'] == 12 and out['columns'][0]['char_used'] == 'C'
    assert out['primary_key'] == [] and out['foreign_keys'][0]['target_columns'] == ['CODE']


@pytest.mark.parametrize('bad', ['hasMore', 'count', 'offset', 'statement'])
def test_ords_http_response_must_be_complete(monkeypatch, bad):
    result = dict(items=[row()], hasMore=False, count=1, offset=0)
    stmt = dict(statementType='query', result=0, resultSet=result)
    if bad == 'hasMore': result['hasMore'] = True
    if bad == 'count': result['count'] = 2
    if bad == 'offset': result['offset'] = 1
    if bad == 'statement': stmt['result'] = 1
    class Opener:
        def open(self, request, timeout):
            return io.BytesIO(json.dumps(dict(items=[stmt])).encode())
    monkeypatch.setattr(ords.urllib.request, 'build_opener', lambda *a: Opener())
    with pytest.raises(ToolError):
        ords._post_dictionary(URL, 'select 1 from dual', [], 'ADMIN', 'not-real')


def test_ords_http_error_redacts_server_body(monkeypatch):
    class Opener:
        def open(self, request, timeout):
            raise urllib.error.HTTPError(URL, 401, 'secret-must-not-appear', {}, None)
    monkeypatch.setattr(ords.urllib.request, 'build_opener', lambda *a: Opener())
    with pytest.raises(ToolError) as error:
        ords._post_dictionary(URL, 'select 1 from dual', [], 'ADMIN', 'not-real')
    assert '401' in str(error.value) and 'secret-must-not-appear' not in str(error.value)


def test_no_unknown_transport_or_missing_credentials(monkeypatch):
    with pytest.raises(ToolError, match='transport'):
        extract_configured(dict(transport='unknown'))
    monkeypatch.delenv('ADB_USER', raising=False)
    monkeypatch.delenv('ADB_PASSWORD', raising=False)
    with pytest.raises(ToolError, match='ADB_USER'):
        ords.extract_ords(config())
