import copy,json
from pathlib import Path
import pytest
from smml_tool.core import ToolError,ref,digest
from smml_tool.generator import build_model,changes
from smml_tool.bundle import load_bundle,save_bundle
from smml_tool.workbook import payload_for,read_review
from smml_tool.ui_config import customer_generation_config
from test_relationship_models import source,settings,physical


def config():
    return customer_generation_config({'model':dict(settings(),subject_area_prefix='SH',business_model_prefix='SH')})['model']
def logical(model):return [d['logicalTable'] for d in model['files'].values() if 'logicalTable' in d]


def test_one_subject_area_one_business_model_and_all_source_folders():
    m=build_model(source(),config())
    assert {r[0] for r in m['review']}=={'SH'}
    areas=[d['subjectArea'] for d in m['files'].values() if 'subjectArea' in d]
    assert len(areas)==1 and areas[0]['name']=='SH'
    bms=[d['businessModel'] for d in m['files'].values() if 'businessModel' in d]
    assert len(bms)==1 and areas[0]['sourceBusinessModel']==ref('businessModel',bms[0]['name'])
    folders=[d['presentationTable'] for d in m['files'].values() if 'presentationTable' in d]
    assert {t['name'] for t in folders}=={'COUNTRIES','CUSTOMERS','SALES'}
    assert len(folders)==3 and m['stats']['subject_areas']==1
    assert len(logical(m))==6  # one shared attribute and one native-grain count/measure projection per table
    assert {x['rule'] for x in m['measure_classification']}=={'SUM'}


def test_physical_layer_byte_equivalent_to_legacy_strategy():
    new=build_model(source(),config());old=build_model(source(),settings())
    assert physical(new)==physical(old)
    assert new['stats']['physical_foreign_keys']==2
    assert new['stats']['logical_foreign_key_joins']==2


def test_common_dimension_foreign_key_is_not_duplicated_on_own_measure_projection():
    m=build_model(source(),config());tables={t['name']:t for t in logical(m)}
    assert len(tables)==6
    assert tables['CUSTOMERS']['joins']==[dict(rightTable=ref('logicalTable','SH','COUNTRIES'),joinType='INNER',cardinality='MANY_TO_ONE')]
    assert tables['CUSTOMERS（メジャー）']['joins']==[dict(rightTable=ref('logicalTable','SH','CUSTOMERS'),joinType='INNER',cardinality='MANY_TO_ONE')]
    byref={ref('logicalTable','SH',name):t for name,t in tables.items()}
    for t in tables.values():
        for j in t.get('joins',[]):assert byref[j['rightTable']]['type']=='DIMENSION'


def test_all_category_rows_can_be_renamed_together_and_mixed_categories_rejected():
    before=build_model(source(),config());rows=copy.deepcopy(before['review'])
    for row in rows:row[0]='営業'
    after=build_model(source(),config(),rows)
    assert changes(before,after)['physical_layer_unchanged']
    assert [d['subjectArea']['name'] for d in after['files'].values() if 'subjectArea' in d]==['営業']
    rows[0][0]='別カテゴリ'
    with pytest.raises(ToolError,match='カテゴリ|同一テーブル'):build_model(source(),config(),rows)


def test_object_aliases_must_be_unique_across_all_folders():
    m=build_model(source(),config());rows=copy.deepcopy(m['review'])
    for row in rows:
        if row[2]=='S.CUSTOMERS':row[1]='COUNTRIES'
    with pytest.raises(ToolError,match='オブジェクト別名'):build_model(source(),config(),rows)


def test_measure_projection_alias_is_collision_safe_and_column_refs_follow_it():
    m=build_model(source(),config());rows=copy.deepcopy(m['review'])
    for row in rows:
        if row[2]=='S.CUSTOMERS':row[1]='COUNTRIES（メジャー）'
    after=build_model(source(),config(),rows)
    names=[t['name'].casefold() for t in logical(after)]
    assert len(names)==len(set(names))
    assert after['validation']['reference_integrity']=='passed'


def test_rename_and_delete_preserve_physical_graph_and_shared_dimensions():
    m=build_model(source(),config());rows=copy.deepcopy(m['review'])
    for row in rows:
        if row[2]=='S.COUNTRIES' and row[3]=='NAME':row[4]='国名変更'
        if row[2]=='S.SALES' and row[3]=='AMOUNT':row[7]='TRUTH'
    after=build_model(source(),config(),rows)
    assert physical(after)==physical(m) and after['stats']['subject_areas']==1
    assert after['stats']['measure_columns']==1
    assert any(c['name']=='国名変更' for t in logical(after) for c in t['logicalColumns'])
    assert build_model(source(),config(),m['review'])['files']==m['files']


def test_key_deletion_drops_only_its_logical_relation():
    m=build_model(source(),config());rows=copy.deepcopy(m['review'])
    for row in rows:
        if row[2]=='S.SALES' and row[3]=='CUST_ID':row[7]='TRUTH'
    after=build_model(source(),config(),rows)
    assert physical(after)==physical(m)
    assert after['stats']['logical_foreign_key_joins']==1 and after['stats']['subject_areas']==1
    assert len([d for d in after['files'].values() if 'presentationTable' in d])==3


def test_all_excluded_keeps_physical_and_does_not_create_empty_subject():
    m=build_model(source(),config());rows=copy.deepcopy(m['review'])
    for row in rows:row[7]='TRUTH'
    after=build_model(source(),config(),rows)
    assert after['files']==physical(m) and after['stats']['subject_areas']==0


def test_legacy_strategy_still_has_distinct_subjects_and_fingerprint_options_unchanged():
    m=build_model(source(),settings())
    assert m['stats']['subject_areas']==3 and 'subject_area_layout' not in m['config']
    assert build_model(source(),settings())['files']==m['files']


def test_saved_shared_bundle_reloads_and_workbook_instructions_allow_one_category(tmp_path,monkeypatch):
    from smml_tool import workbook
    monkeypatch.setattr(workbook,'artifact_runtime',lambda:None)
    m=build_model(source(),config());save_bundle(m,tmp_path/'base')
    actual=load_bundle(tmp_path/'base')
    assert actual['files']==m['files']
    assert read_review(tmp_path/'base/review.xlsx',actual)==m['review']
    assert any('全表の全行を同じ名前' in str(row) for row in payload_for(m)['instructions'])
