"""Fixed customer workflow; legacy bundles retain their immutable old rules."""
import copy,json
from pathlib import Path
import pytest
from smml_tool.core import ToolError
from smml_tool.generator import build_model
from smml_tool.ui_config import customer_generation_config, require_customer_model, export_public_config
from smml_tool import ords,adb,bundle
from test_relationship_models import source
ROOT=Path(__file__).resolve().parents[1]


def config():return json.loads((ROOT/'examples/config.example.json').read_text())
def rules():return customer_generation_config(config())['model']


def test_new_generation_rules_override_old_hidden_options_without_mutating_input():
    old=config();old['db']['include_views']=False
    old['ui']['data_source']='offline'
    old['model'].update(strategy='single_table',auto_decimal_measures=False,constraint_policy='validated_only',measures={'S.SALES':{'AMOUNT':'AVG'}})
    before=copy.deepcopy(old);new=customer_generation_config(old)
    assert old==before and new['db']['include_views'] is True
    assert new['model']['strategy']=='foreign_key_star' and new['model']['auto_decimal_measures'] is True
    assert new['model']['constraint_policy']=='declared' and 'measures' not in new['model']
    assert 'data_source' not in new['ui']


def test_declared_disabled_nonrely_constraints_are_preserved_without_guessing():
    s=source()
    for t in s['tables']:
        for k in t['key_constraints']+t['foreign_keys']:k['rely']=False
    m=build_model(s,rules());require_customer_model(m)
    assert m['stats']['physical_foreign_keys']==2
    assert m['stats']['logical_foreign_key_joins']==2
    assert any('DISABLED/NOT VALIDATED' in w for w in m['warnings'])
    for t in s['tables']:t['foreign_keys']=[]
    no_fk=build_model(s,rules())
    assert no_fk['stats']['physical_foreign_keys']==0
    assert no_fk['stats']['logical_foreign_key_joins']==0


def test_existing_table_and_view_keys_use_same_modeling_rules():
    s=source();original=build_model(s,rules())
    for t in s['tables']:t['object_type']='VIEW'
    views=build_model(s,rules())
    assert original['files']==views['files']
    assert views['stats']['physical_foreign_keys']==2 and views['stats']['measure_columns']==2


def test_all_customer_measures_sum_including_former_price_overrides():
    m=build_model(source(),rules())
    assert {r['rule'] for r in m['measure_classification']}=={'SUM'}
    for doc in m['files'].values():
        for col in doc.get('logicalTable',{}).get('logicalColumns',[]):
            if 'aggregation' in col:assert col['aggregation']['rule']=='SUM'
    assert not any('AVG' in w or 'measuresで' in w for w in m['warnings'])
    assert {row[0] for row in m['review']}=={'SH'}


def test_legacy_custom_aggregation_bundle_cannot_enter_fixed_customer_workflow():
    old=build_model(source(),dict(oac_connection="'system'.'TEST'",strategy='foreign_key_star',constraint_policy='validated_or_rely',measures={'S.SALES':{'AMOUNT':'AVG'}}))
    with pytest.raises(ToolError,match='旧版'):require_customer_model(old)
    assert old['measure_classification'][0]['rule']=='AVG'


def test_defaults_have_no_customer_aggregation_map_and_export_is_secret_free():
    c=config();assert 'measures' not in c['model'] and c['model']['subject_area_prefix']=='SH'
    c=customer_generation_config(c)
    public=export_public_config(c,username='admin')
    assert 'measures' not in public['model'] and public['db']['include_views'] is True


def test_simplified_ui_removes_six_modeling_choices_even_with_old_config(tmp_path,monkeypatch):
    testing=pytest.importorskip('streamlit.testing.v1')
    c=config();c['model']['measures']={'S.SALES':{'AMOUNT':'AVG'}};c['ui']['data_source']='offline'
    c['db']['include_views']=False
    p=tmp_path/'settings.json';p.write_text(json.dumps(c))
    monkeypatch.setenv('ADB_SMML_CONFIG',str(p));monkeypatch.delenv('ADB_PASSWORD',raising=False)
    app=testing.AppTest.from_file(str(ROOT/'app.py')).run(timeout=20)
    assert not app.exception
    assert not app.radio
    labels={w.label for group in [app.checkbox,app.selectbox,app.text_area] for w in group}
    assert not labels&{'モデル生成方式','小数桁付きNUMBERをメジャーとして自動判定','外部キーの採用条件','指定したビューも取得対象に含める','明示的な集計規則 JSON'}
    assert next(w for w in app.text_input if w.label=='サブジェクト領域名').value=='SH'
    assert any('集計はSUM' in c.value for c in app.caption)


def test_actual_ui_generation_passes_fixed_rules_and_view_scope(tmp_path,monkeypatch):
    testing=pytest.importorskip('streamlit.testing.v1')
    c=config();c['model']['measures']={'S.SALES':{'AMOUNT':'AVG'}};c['db']['include_views']=False
    p=tmp_path/'settings.json';p.write_text(json.dumps(c))
    monkeypatch.setenv('ADB_SMML_CONFIG',str(p));monkeypatch.setenv('ADB_SMML_HOME',str(tmp_path));monkeypatch.setenv('ADB_PASSWORD','unit-only')
    seen={}
    def extract(db,secrets):seen['db']=db;return source()
    save=bundle.save_bundle
    def capture(model,path,**kwargs):
        seen['model']=model
        return save(model,path,with_excel=False,**kwargs)
    monkeypatch.setattr(adb,'extract_configured',extract);monkeypatch.setattr(bundle,'save_bundle',capture)
    app=testing.AppTest.from_file(str(ROOT/'app.py')).run(timeout=20)
    next(b for b in app.button if b.label=='3層SMMLと確認用Excelを生成').click();app.run(timeout=20)
    assert not app.exception and not app.error
    assert seen['db']['include_views'] is True
    assert seen['model']['config']['constraint_policy']=='declared'
    assert {r['rule'] for r in seen['model']['measure_classification']}=={'SUM'}
    assert {r[0] for r in seen['model']['review']}=={'SH'}


def test_ords_mixed_tables_views_use_identical_dictionary_query(monkeypatch):
    from test_ords import row
    c=customer_generation_config(config())['db'];c.update(schema='CaseOwner',tables=['CaseTable','CaseView'])
    a=row();b=row();b.update(table_name='CaseView',table_type='VIEW');c['expected_database']=a['database_name']
    seen={}
    def query(endpoint,sql,binds,user,password):seen['sql']=sql;return [a,b]
    monkeypatch.setattr(ords,'_post_dictionary',query)
    result=ords.extract_ords(c,{'user':'U','password':'unit-only'})
    assert "'TABLE','VIEW'" in seen['sql']
    assert {t['object_type'] for t in result['tables']}=={'TABLE','VIEW'}


def test_relationship_grid_omits_database_status_validation_and_rely_without_changing_model(tmp_path,monkeypatch):
    testing=pytest.importorskip('streamlit.testing.v1')
    c=config();settings=tmp_path/'settings.json';settings.write_text(json.dumps(c))
    monkeypatch.setenv('ADB_SMML_CONFIG',str(settings));monkeypatch.setenv('ADB_SMML_HOME',str(tmp_path))
    model=build_model(source(),rules());original=copy.deepcopy(model)
    baseline=tmp_path/'baseline';bundle.save_bundle(model,baseline,with_excel=False)
    before=(baseline/'relationships.json').read_bytes()
    app=testing.AppTest.from_file(str(ROOT/'app.py')).run(timeout=20)
    next(w for w in app.text_input if w.label.startswith('既存のモデルを読み込む')).set_value(str(baseline))
    next(w for w in app.button if w.label=='既存モデルを読み込む').click();app.run(timeout=20)
    assert not app.exception and not app.error
    frame=app.dataframe[1].value
    assert list(frame.columns)==['制約名','参照元','参照先','外部キー列','参照先キー列','参照先キー','結合方式']
    assert not {'状態','検証','RELY','status','validated','rely'}&set(frame.columns)
    assert len(frame)==2 and set(frame['制約名'])=={'CUST_COUNTRY_FK','SALES_CUST_FK'}
    assert (baseline/'relationships.json').read_bytes()==before
    assert model==original
    assert all(r['status']=='DISABLED' and r['validated']=='NOT VALIDATED' for r in bundle.load_bundle(baseline)['relationships'])
