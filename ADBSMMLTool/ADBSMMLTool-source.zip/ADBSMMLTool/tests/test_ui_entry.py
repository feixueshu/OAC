from pathlib import Path
import pytest


def test_local_ui_defaults_to_real_adb_and_exposes_four_steps():
    testing=pytest.importorskip('streamlit.testing.v1')
    root=Path(__file__).resolve().parents[1]
    app=testing.AppTest.from_file(str(root/'app.py')).run(timeout=20)
    assert not app.exception
    assert not app.radio
    assert not any(w.label in {'モデル生成方式','外部キーの採用条件'} for w in app.selectbox)
    assert [t.label for t in app.tabs]==['1 モデル生成','2 Excel変更の反映','3 GitHub同期','4 OAC反映']
    assert any('対象表をダブルクリック → プレビュー' in message.value for message in app.info)
