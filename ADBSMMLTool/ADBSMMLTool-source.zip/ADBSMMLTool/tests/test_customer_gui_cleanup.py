import copy,json
from pathlib import Path
import pytest
from openpyxl import load_workbook
from smml_tool import bundle,workbook,git_sync
from smml_tool.generator import build_model
from smml_tool.core import ToolError
from smml_tool.ui_config import customer_generation_config
from test_relationship_models import source
ROOT=Path(__file__).resolve().parents[1]
CONFIRM='同期先と差分を確認しました。コミットとGitHubへのプッシュを許可します。'
PUSH='確認した内容をGitHubへプッシュ'


@pytest.fixture
def customer_app(tmp_path,monkeypatch):
    testing=pytest.importorskip('streamlit.testing.v1')
    config=json.loads((ROOT/'examples/config.example.json').read_text());p=tmp_path/'settings.json';p.write_text(json.dumps(config))
    monkeypatch.setenv('ADB_SMML_HOME',str(tmp_path));monkeypatch.setenv('ADB_SMML_CONFIG',str(p))
    data=source();data['source']='adb_dictionary_read_only'
    m=build_model(data,customer_generation_config(config)['model']);base=tmp_path/'base';bundle.save_bundle(m,base,with_excel=False)
    rows=copy.deepcopy(m['review']);rows[0][4]='番号（確認用）'
    changed=build_model(data,m['config'],rows);updated=tmp_path/'updated';bundle.save_bundle(changed,updated,previous=m,with_excel=False)
    app=testing.AppTest.from_file(str(ROOT/'app.py')).run(timeout=20)
    next(w for w in app.text_input if w.label.startswith('既存のモデルを読み込む')).set_value(str(base))
    next(w for w in app.button if w.label=='既存モデルを読み込む').click();app.run(timeout=20)
    assert not app.exception
    return app,base,updated,m


def test_debug_and_version_instructions_removed_and_update_has_no_duplicate_fk(customer_app):
    app,_,updated,_=customer_app
    app.session_state['updated']=str(updated);app.run(timeout=20)
    assert not app.exception
    labels=[w.label for w in app.expander]
    assert labels.count('FKとメジャーの判定結果')==1
    assert '技術情報 ローカル検証結果' not in labels
    assert 'このバージョンの反映手順' not in labels
    assert not app.json
    assert not any('物理レイヤー変更なし' in w.value for w in app.caption)
    assert any('削除フラグはTRUE' in w.value for w in app.info)
    assert not any('指紋' in w.value or 'SHA-256' in w.value for group in [app.info,app.caption,app.markdown] for w in group)


def test_push_option_replaced_by_message_and_deliberate_confirmation(customer_app,monkeypatch):
    app,_,_,_=customer_app;calls=[]
    def sync(*args,**kwargs):
        calls.append((args,kwargs))
        return dict(changed_files=3,pushed=True,commit='unit-only-commit',plan={})
    monkeypatch.setattr(git_sync,'apply_sync',sync)
    app.run(timeout=20)
    assert next(w for w in app.button if w.label==PUSH).disabled
    assert not any(w.label.startswith('指定リポジトリとブランチへプッシュする') for w in app.checkbox)
    assert any('OACには自動デプロイしません' in w.value for w in app.caption)
    next(w for w in app.checkbox if w.label==CONFIRM).check();app.run(timeout=20)
    assert not next(w for w in app.button if w.label==PUSH).disabled
    next(w for w in app.button if w.label==PUSH).click();app.run(timeout=20)
    assert not app.exception and len(calls)==1
    assert calls[0][1]['push'] is True and calls[0][1]['confirmed'] is True
    assert any('プッシュが完了' in x.value for x in app.success)
    assert not app.json


def test_confirmation_resets_when_destination_changes(customer_app):
    app,_,_,_=customer_app
    next(w for w in app.checkbox if w.label==CONFIRM).check();app.run(timeout=20)
    assert not next(w for w in app.button if w.label==PUSH).disabled
    next(w for w in app.text_input if w.label=='現在のブランチ名').set_value('another-branch');app.run(timeout=20)
    assert not next(w for w in app.checkbox if w.label==CONFIRM).value
    assert next(w for w in app.button if w.label==PUSH).disabled


def test_confirmation_resets_when_source_model_changes(customer_app):
    app,_,updated,_=customer_app
    next(w for w in app.checkbox if w.label==CONFIRM).check();app.run(timeout=20)
    app.session_state['updated']=str(updated);app.run(timeout=20)
    assert not next(w for w in app.checkbox if w.label==CONFIRM).value
    assert next(w for w in app.button if w.label==PUSH).disabled


def test_portable_excel_has_no_batch_binding_sheet(tmp_path,monkeypatch):
    monkeypatch.setattr(workbook,'artifact_runtime',lambda:None)
    m=build_model(source(),dict(oac_connection='unit-only',strategy='single_table_star'))
    p=tmp_path/'review.xlsx';workbook.export_workbook(m,p)
    w=load_workbook(p,read_only=True)
    assert w.sheetnames==['テーブル一覧','使い方']
    w.close()
    assert workbook.read_review(p,m)==m['review']
    other=copy.deepcopy(m);other['config']['subject_area_prefix']='別モデル'
    assert workbook.read_review(p,other)==m['review']


def test_generated_customer_instructions_have_no_fingerprint(customer_app):
    _,_,_,m=customer_app
    guide=bundle.deployment_guide(m,'https://example.invalid/ui/')
    assert 'モデル指紋' not in guide and 'SHA-256' not in guide

