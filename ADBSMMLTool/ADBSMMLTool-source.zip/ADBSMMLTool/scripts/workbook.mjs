import fs from 'node:fs/promises';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const [inputPath, outputPath, previewPath] = process.argv.slice(2);
if (!inputPath || !outputPath) throw new Error('Usage: node workbook.mjs payload.json review.xlsx [preview.png]');
const payload = JSON.parse(await fs.readFile(inputPath, 'utf8'));
const wb = Workbook.create();
const s = wb.worksheets.add('テーブル一覧');
const end = payload.rows.length + 1;
const literal = value => typeof value === 'string' && /^[=+@-]/.test(value) ? "'" + value : value;
s.getRange('A1:H' + end).values = [payload.headers, ...payload.rows].map(row => row.map(literal));
s.getRange('A1:H' + end).format.font = { name: 'Yu Gothic', size: 11 };
s.getRange('A1:H' + end).format.wrapText = true;
s.getRange('A1:H' + end).format.verticalAlignment = 'center';
s.getRange('A1:H' + end).format.rowHeight = 44;
for (const [i, width] of [30,44,26,28,44,16,12,18].entries()) {
  s.getRange(String.fromCharCode(65+i) + '1:' + String.fromCharCode(65+i) + end).format.columnWidth = width;
}
const header = s.getRange('A1:H1');
header.format.fill = '#23374D';
header.format.font = {name:'Yu Gothic',size:11,bold:true,color:'#FFFFFF'};
header.format.rowHeight = 34;
if (end >= 2) {
  const table = s.tables.add('A1:H' + end, true, 'DataItems');
  table.style = 'TableStyleMedium2';
  s.getRange('H2:H' + end).setNumberFormat('@');
  s.getRange('H2:H' + end).dataValidation = {rule:{type:'list',values:['TRUE','FALSE']}};
  s.getRange('A2:H' + end).conditionalFormats.addCustom('OR($H2=TRUE,$H2="TRUE")',{fill:'#FDE9E7',font:{color:'#A4262C'}});
  for (const col of ['A','B','E','H']) s.getRange(col+'2:'+col+end).format.font = {name:'Yu Gothic',size:11,color:'#165DAB'};
  s.getRange('G2:G' + end).setNumberFormat('0');
  // Long comments must remain readable rather than clipping at a fixed row height.
  for (let i=0; i<payload.rows.length; i++) {
    const r=payload.rows[i];
    const lines = Math.max(2, ...[0,1,2,3,4].map(j => Math.ceil(String(r[j]).length/[14,20,12,13,20][j])));
    if(lines>2) s.getRange('A'+(i+2)+':H'+(i+2)).format.rowHeight = lines*18+8;
  }
}
s.freezePanes.freezeRows(1);
s.freezePanes.freezeColumns(4);
for(const [name, rows] of [['使い方',payload.instructions]]) {
  const sheet=wb.worksheets.add(name);
  sheet.getRange('A1:B'+rows.length).values=rows.map(r=>r.map(literal));
  sheet.getRange('A1:B'+rows.length).format.font={name:'Yu Gothic',size:11};
  sheet.getRange('A1:B'+rows.length).format.wrapText=true;
  sheet.getRange('A1:B'+rows.length).format.verticalAlignment='center';
  sheet.getRange('A1:B'+rows.length).format.rowHeight=46;
  sheet.getRange('A1:A'+rows.length).format.columnWidth=34;
  sheet.getRange('B1:B'+rows.length).format.columnWidth=112;
  sheet.getRange('A1:B1').format.fill='#23374D';
  sheet.getRange('A1:B1').format.font={name:'Yu Gothic',bold:true,color:'#FFFFFF',size:12};
}
wb.recalculate();
const inspection=await wb.inspect({kind:'table',range:'テーブル一覧!A1:H7',include:'values,formulas',tableMaxRows:7,tableMaxCols:8,maxChars:3000});
console.log(inspection.ndjson);
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:50},summary:'final formula error scan'});
console.log(errors.ndjson);
const file=await SpreadsheetFile.exportXlsx(wb);
await file.save(outputPath);
if(previewPath) {
  for (const [sheetName, range, path] of [
    ['テーブル一覧','A1:H7',previewPath],
    ['使い方',`A1:B${payload.instructions.length}`,previewPath.replace(/\.png$/,'.instructions.png')],
  ]) {
    const preview=await wb.render({sheetName,range,scale:1.2,format:'png'});
    await fs.writeFile(path,new Uint8Array(await preview.arrayBuffer()));
  }
}
console.log(JSON.stringify({output:outputPath,rows:payload.rows.length}));
