from __future__ import annotations

import copy

from .core import (ToolError, check_name, comment_name, datatype, digest, filename,
                   initial_review, model_config, ref, table_id, validate_metadata, NUMERIC_TYPES, normalize_delete_flag)
from .validation import validate_files


def check_review(metadata: dict, config: dict, rows: list[list]) -> list[list]:
    expected = {(r[2], r[3]): r for r in initial_review(metadata, config)}
    positions = {key: i for i, key in enumerate(expected)}
    seen = set()
    table_names = {}
    column_names = {}
    categories = {}
    checked = []
    for number, row in enumerate(rows, 2):
        row=list(row)
        if len(row) != 8:
            raise ToolError(f"Excel {number}行: 8列が必要です。")
        identity = (row[2], row[3])
        if identity not in expected or identity in seen:
            raise ToolError(f"Excel {number}行: 未知/重複した物理列: {identity}")
        seen.add(identity)
        baseline = expected[identity]
        if row[5:7] != baseline[5:7]:
            raise ToolError(f"Excel {number}行: 属性/サイズは変更禁止です。ADBから再取得してください。")
        row[7]=normalize_delete_flag(row[7],row=number)
        category, alias, _, _, column = row[:5]
        for name in (category, alias, column):
            check_name(name)
        if category == alias:
            raise ToolError(f"Excel {number}行: Subject Area と Presentation Table は同名にできません。")
        previous = table_names.setdefault(row[2], (category, alias))
        if previous != (category, alias):
            raise ToolError(f"Excel {number}行: 同一テーブル内のカテゴリ/オブジェクト別名を統一してください。")
        if row[7] == "FALSE":
            owner = categories.setdefault(category.casefold(), row[2])
            if owner != row[2] and config.get("subject_area_layout")!="single":
                raise ToolError("V1は一表一Subject Areaです。複数表を同じカテゴリへ結合できません。")
            names = column_names.setdefault(row[2], {config["row_count_name"].casefold()})
            if column.casefold() in names:
                raise ToolError(f"Excel {number}行: 同一テーブル内に重複する論理名があります: {column}")
            names.add(column.casefold())
        checked.append(list(row))
    missing = set(expected) - seen
    if missing:
        raise ToolError(f"Excelから{len(missing)}行が欠落しています。行を消さずTRUEを設定してください。")
    if config.get('subject_area_layout')=='single':
        if len({r[0] for r in checked})>1:raise ToolError('単一Subject Areaのカテゴリ別名は全行で同じ名前にしてください。')
        owners={}
        for row in checked:
            if row[7]=='FALSE':
                other=owners.setdefault(row[1].casefold(),row[2])
                if other!=row[2]:raise ToolError('同じSubject Area内のオブジェクト別名が重複しています。')
    return sorted(checked, key=lambda r: (r[2], positions[(r[2], r[3])]))


def build_model(source: dict, settings: dict, review: list[list] | None = None) -> dict:
    metadata = validate_metadata(source)
    config = model_config(settings)
    rows = check_review(metadata, config, review if review is not None else initial_review(metadata, config))
    if config["strategy"]=="foreign_key_star" and config.get("subject_area_layout")=="single":
        from .shared_subject import build_shared_subject_model
        return build_shared_subject_model(metadata,config,rows)
    if config["strategy"]=="foreign_key_star":
        from .relationships import build_relationship_model
        return build_relationship_model(metadata,config,rows)
    lookup = {(r[2], r[3]): r for r in rows}
    files = {}
    paths = set()
    targets = set()
    warnings = ["V1は一表一Business Model/Subject Areaの単表FACT。表をまたぐJoin・階層・RLSは自動生成しません。",
                "全アクティブ表に SUM(1) の行数メジャーを自動生成。数値列を無条件にSUMしません。",
                "削除フラグは論理/表示列にのみ適用。物理列およびADBの表/データは変更しません。"]
    if config["strategy"] == "single_table_star":
        warnings[0] = "各物理表を属性DIMENSIONと集計FACTの2投影に分離。同じ物理表を共有し、表をまたぐJoinは生成しません。"
    configured = config["measures"]
    actual_tables = {table_id(t): t for t in metadata["tables"]}
    if set(configured) - set(actual_tables):
        raise ToolError(f"measuresに未知の表があります: {sorted(set(configured) - set(actual_tables))}")
    for ident, measures in configured.items():
        actual_cols = {c["name"] for c in actual_tables[ident]["columns"]}
        if set(measures) - actual_cols:
            raise ToolError(f"{ident}: measuresに未知の列があります。")

    def add(path, kind, body):
        normalized = path.casefold()
        if normalized in paths:
            raise ToolError(f"ファイル名の正規化により衝突しました: {path}")
        paths.add(normalized)
        files[path] = {kind: body}

    db = config["database_name"]
    add(f"physical/{filename(db)}.json", "database", dict(name=db, databaseType="ORACLE_ADW",
        connectionPools=[dict(name=config["connection_pool"], connection=config["oac_connection"],
            maxConnections=10, requiresFullyQualifedTableNames=True, connectionTimeout=5,
            connectionTimeoutUnit="MINUTES", multithreaded=True, supportParams=True)],
        allowDirectDatabaseRequests=False, allowPopulateQueries=False))
    for owner in sorted({t["owner"] for t in metadata["tables"]}):
        add(f"physical/{filename(db)}/{filename(owner)}.json", "schema", {"name": owner})
        targets.add(ref("schema", db, owner))
    targets.add(ref("database", db))
    for table in metadata["tables"]:
        ident = table_id(table)
        base = f"physical/{filename(db)}/{filename(table['owner'])}/{filename(table['name'])}.json"
        physical_columns = []
        for col in table["columns"]:
            physical = dict(name=col["name"], dataType=datatype(col["data_type"]),
                            length=col.get("length", 0) or 0, nullable=col.get("nullable", True))
            if col.get("comment"):
                physical["description"] = col["comment"]
            physical_columns.append(physical)
            targets.add(ref("physicalColumn", db, table["owner"], table["name"], col["name"]))
        physical = dict(name=table["name"], sourceType="TABLE", physicalColumns=physical_columns,
                        caching={"enable": False})
        if table.get("comment"):
            physical["description"] = table["comment"]
        add(base, "physicalTable", physical)
        targets.add(ref("physicalTable", db, table["owner"], table["name"]))
        if table.get("foreign_keys"):
            warnings.append(f"{ident}: FKはmetadata.jsonに保存済みですが、Joinとしては生成していません。")
        active = [c for c in table["columns"] if lookup[(ident, c["name"])][7] == "FALSE"]
        if not active:
            warnings.append(f"{ident}: 全列TRUEのため論理/表示オブジェクトを除外し、物理表のみ保持。")
            continue
        sample = lookup[(ident, active[0]["name"])]
        category, alias = sample[:2]
        # Business-model identity stays stable when the user changes Japanese labels.
        bm_base = f"{config['business_model_prefix']} - {ident}"
        bm = bm_base if len(bm_base) <= 128 else bm_base[:115] + "-" + digest(ident)[:12]
        check_name(bm)
        add(f"logical/{filename(bm)}.json", "businessModel", dict(name=bm, disable=False))
        targets.add(ref("businessModel", bm))
        targets.add(ref("logicalTable", bm, alias))
        logical_columns = []
        presentation_columns = []
        for col in active:
            row = lookup[(ident, col["name"])]
            name = row[4]
            logical = dict(name=name, dataType=datatype(col["data_type"]), writeable=False,
                logicalColumnSource={"derivedFrom": "PHYSICAL_COLUMNS", "physicalMappings": [{
                    "logicalTableSource": "ADB Source", "physicalExpression": {
                        "expressionTemplate": "%1", "expressionObjects": [ref("physicalColumn", db, table["owner"], table["name"], col["name"])]}}]})
            rule = config["measures"].get(ident, {}).get(col["name"])
            if rule:
                if rule in ("SUM", "AVG") and datatype(col["data_type"]) not in NUMERIC_TYPES:
                    raise ToolError(f"{ident}.{col['name']}: {rule} は数値型にのみ指定できます。")
                logical["aggregation"] = {"rule": rule}
            if col.get("comment"):
                logical["description"] = col["comment"]
            logical_columns.append(logical)
            presentation_columns.append(dict(name=name, sourceLogicalColumn=ref("logicalColumn", bm, alias, name)))
            targets.add(ref("logicalColumn", bm, alias, name))
            if not col.get("comment"):
                warnings.append(f"{ident}.{col['name']}: COMMENT未定義のため物理名を使用。")
        count = config["row_count_name"]
        logical_columns.append(dict(name=count, dataType="NUMERIC", writeable=False,
            description="自動生成した行数。SUM(1)。ExcelのDB列一覧には含まれません。",
            logicalColumnSource={"derivedFrom": "PHYSICAL_COLUMNS", "physicalMappings": [{
                "logicalTableSource": "ADB Source", "physicalExpression": {"expressionTemplate": "1", "expressionObjects": []}}]},
            aggregation={"rule": "SUM"}))
        targets.add(ref("logicalColumn", bm, alias, count))
        presentation_columns.append(dict(name=count, sourceLogicalColumn=ref("logicalColumn", bm, alias, count)))
        logical_table = dict(name=alias, type="FACT", logicalColumns=logical_columns,
            logicalTableSources=[dict(name="ADB Source", tableMapping={"tables": [ref("physicalTable", db, table["owner"], table["name"])]})])
        count_table = alias
        if config["strategy"] == "single_table_star":
            # Two semantic projections of ONE physical source, never a guessed
            # join between business tables. Attribute tuples define members;
            # duplicate database rows remain in the FACT and contribute to SUM(1).
            fact_alias = alias[:118] + "（自動集計）"
            if fact_alias.casefold() == alias.casefold():
                fact_alias = alias[:108] + "（FACT-" + digest(alias)[:8] + "）"
            check_name(fact_alias)
            measures = [c for c in logical_columns if c.get("aggregation")]
            attributes = [copy.deepcopy(c) for c in logical_columns[:-1]]
            for c in attributes:
                c.pop("aggregation", None)
            logical_table.update(type="DIMENSION", logicalColumns=attributes,
                primaryKey=[c["name"] for c in attributes],
                description="単表の属性組合せを表す技術キー（全保持属性）。DBのPK/行一意性を宣言するものではありません。")
            fact = dict(name=fact_alias, type="FACT", logicalColumns=measures,
                logicalTableSources=copy.deepcopy(logical_table["logicalTableSources"]),
                joins=[dict(rightTable=ref("logicalTable", bm, alias), joinType="INNER", cardinality="MANY_TO_ONE")])
            add(f"logical/{filename(bm)}/{filename(fact_alias)}.json", "logicalTable", fact)
            targets.add(ref("logicalTable", bm, fact_alias))
            measure_names = {c["name"] for c in measures}
            for c in measures:
                targets.add(ref("logicalColumn", bm, fact_alias, c["name"]))
            for c in presentation_columns:
                if c["name"] in measure_names:
                    c["sourceLogicalColumn"] = ref("logicalColumn", bm, fact_alias, c["name"])
            targets.discard(ref("logicalColumn", bm, alias, count))
            count_table = fact_alias
        add(f"logical/{filename(bm)}/{filename(alias)}.json", "logicalTable", logical_table)
        add(f"presentation/{filename(category)}.json", "subjectArea", dict(name=category,
            sourceBusinessModel=ref("businessModel", bm), implicitFactColumn=ref("logicalColumn", bm, count_table, count)))
        add(f"presentation/{filename(category)}/{filename(alias)}.json", "presentationTable",
            dict(name=alias, presentationColumns=presentation_columns))
        targets.add(ref("subjectArea", category))
        targets.add(ref("presentationTable", category, alias))
    def check_references(value, field=None):
        if isinstance(value, dict):
            for key, sub in value.items(): check_references(sub, key)
        elif isinstance(value, list):
            for sub in value: check_references(sub, field)
        elif isinstance(value, str) and field in {"sourceBusinessModel", "sourceLogicalColumn", "implicitFactColumn", "expressionObjects", "tables", "rightTable", "drivingTable"}:
            if value not in targets:
                raise ToolError(f"参照先が存在しません: {value}")
    check_references(files)
    validation = validate_files(files)
    validation["reference_integrity"] = "passed"
    active_count = sum(1 for r in rows if r[7] == "FALSE")
    return dict(metadata=metadata, config=config, review=rows, files=files, warnings=warnings,
        validation=validation, stats={"physical_tables": len(metadata["tables"]), "source_columns": len(rows),
            "active_source_columns": active_count, "deleted_semantic_columns": len(rows)-active_count,
            "subject_areas": sum("subjectArea" in d for d in files.values())})


def changes(old: dict, new: dict) -> dict:
    before = old["files"]
    after = new["files"]
    old_rows = {(r[2], r[3]): r for r in old["review"]}
    events = []
    for row in new["review"]:
        previous = old_rows[(row[2], row[3])]
        changed = {name: {"before": previous[index], "after": row[index]} for index, name in
                   ((0, "category"), (1, "object_alias"), (4, "item_alias"), (7, "delete_flag")) if previous[index] != row[index]}
        if changed:
            events.append({"table": row[2], "column": row[3], "changes": changed})
    return {"added": sorted(set(after)-set(before)), "removed": sorted(set(before)-set(after)),
        "modified": sorted(p for p in set(before)&set(after) if before[p] != after[p]), "items": events,
        "database_writes": 0, "physical_layer_unchanged": all(after.get(p) == doc for p, doc in before.items() if p.startswith("physical/"))}
