from __future__ import annotations

import contextlib
import hashlib
import os
import re
import subprocess
import tempfile
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

from .bundle import load_bundle
from .core import ToolError, read_json, write_json
from .privacy import verify_private_repository

MANAGED = ".smml-generated-files.json"


def safe_path(path: str) -> str:
    value = PurePosixPath(path)
    if value.is_absolute() or any(p in ("..", ".git", "") for p in value.parts) or "\\" in path:
        raise ToolError(f"不正な管理対象パス: {path}")
    if len(value.parts) < 2 or value.parts[0] not in {"physical", "logical", "presentation"} or value.suffix != ".json":
        raise ToolError(f"SMML層以外は同期できません: {path}")
    return path


def validate_origin(value: str) -> str:
    # Credentials must never be embedded in a remote URL or logged via git output.
    if re.match(r"^[^/@:]+@[^/:]+:[^\s]+$", value):
        if not value.startswith("git@"):
            raise ToolError("SSHリモートはgit@host:owner/repo.git形式を使用してください。")
    else:
        parts = urlsplit(value)
        if parts.scheme not in {"https", "file"} or parts.username or parts.password or parts.query or parts.fragment:
            raise ToolError("認証情報を含まないHTTPS/SSHリモートが必要です。")
    return value


def git(repo: Path, *args: str, env: dict | None = None) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], text=True, capture_output=True,
                            env=env, timeout=120)
    if result.returncode:
        message = result.stderr.strip()
        token = (env or {}).get("GITHUB_TOKEN") or os.environ.get("GITHUB_TOKEN")
        if token:
            message = message.replace(token, "[REDACTED]")
        raise ToolError(f"git {args[0]} failed: {message[:1000]}")
    return result.stdout.strip()


def ensure_no_symlinks(root: Path, relative: str) -> Path:
    candidate = root / relative
    current = candidate
    while current != root:
        if current.is_symlink():
            raise ToolError(f"同期先がsymlinkです: {relative}")
        current = current.parent
    if not candidate.resolve().is_relative_to(root):
        raise ToolError("同期先がリポジトリ外です。")
    return candidate


def repository_head(repo: Path) -> str | None:
    result = subprocess.run(["git", "-C", str(repo), "rev-parse", "--verify", "--quiet", "HEAD"],
                            text=True, capture_output=True, timeout=30)
    if result.returncode == 0:
        return result.stdout.strip()
    if result.returncode == 1 and git(repo, "symbolic-ref", "--quiet", "--short", "HEAD"):
        return None  # A newly cloned empty repository has an unborn, named branch.
    raise ToolError("HEADを確認できません。破損したリポジトリまたはdetached HEADを確認してください。")


def sync_plan(bundle: str | Path, repo: str | Path, branch: str, expected_origin: str) -> dict:
    model = load_bundle(bundle)
    root = Path(repo).resolve()
    origin = validate_origin(git(root, "remote", "get-url", "origin"))
    if origin != validate_origin(expected_origin):
        raise ToolError("originが指定値と一致しません。誤ったリポジトリには同期しません。")
    top = Path(git(root, "rev-parse", "--show-toplevel")).resolve()
    if top != root or not branch or branch.startswith("-") or git(root, "branch", "--show-current") != branch:
        raise ToolError("リポジトリのルートと現在のブランチを明示してください（自動checkoutしません）。")
    if git(root, "status", "--porcelain", "--untracked-files=all"):
        raise ToolError("同期先がdirtyです。既存の変更を手動で保存してから再実行してください。")
    managed_file = ensure_no_symlinks(root, MANAGED)
    old = read_json(managed_file).get("files", {}) if managed_file.exists() else {}
    for path, expected_hash in old.items():
        target = ensure_no_symlinks(root, safe_path(path))
        if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest() != expected_hash:
            raise ToolError(f"以前の生成ファイルが手動変更されています: {path}。上書きせず確認してください。")
    after = {}
    add, modify, remove = [], [], sorted(set(old)-set(model["files"]))
    for path in sorted(model["files"]):
        target = ensure_no_symlinks(root, safe_path(path))
        source = Path(bundle) / "model" / path
        content_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        after[path] = content_hash
        if target.exists() and path not in old:
            if not target.is_file() or target.read_bytes() != source.read_bytes():
                raise ToolError(f"未管理の既存ファイルを上書きしません: {path}。専用の空リポジトリを使用してください。")
        if not target.exists():
            add.append(path)
        elif hashlib.sha256(target.read_bytes()).hexdigest() != content_hash:
            modify.append(path)
    head = repository_head(root)
    return dict(repo=str(root), branch=branch, origin=origin, head=head, initial_commit_required=head is None,
                added=add, modified=modify, removed=remove, files=after,
                oac_status="NOT_SYNCED_OR_DEPLOYED")


@contextlib.contextmanager
def authentication_environment(token: str | None = None):
    env = os.environ.copy()
    if token:
        env["GITHUB_TOKEN"] = token
    env["GIT_TERMINAL_PROMPT"] = "0"
    if not env.get("GITHUB_TOKEN"):
        yield env
        return
    # Explicit env-token authentication must not be cached by an inherited
    # credential helper (e.g. osxkeychain/store). Override only child-process config.
    count = int(env.get("GIT_CONFIG_COUNT", "0"))
    env[f"GIT_CONFIG_KEY_{count}"] = "credential.helper"
    env[f"GIT_CONFIG_VALUE_{count}"] = ""
    env["GIT_CONFIG_COUNT"] = str(count + 1)
    with tempfile.TemporaryDirectory(prefix="smml-git-") as temp:
        helper = Path(temp) / "askpass"
        helper.write_text('#!/bin/sh\ncase "$1" in *Username*) printf "%s\\n" "x-access-token" ;; *) printf "%s\\n" "$GITHUB_TOKEN" ;; esac\n')
        helper.chmod(0o700)
        env["GIT_ASKPASS"] = str(helper)
        yield env


def apply_sync(bundle: str | Path, repo: str | Path, branch: str, expected_origin: str,
               *, confirmed: bool, push: bool = False, message: str = "Update generated ADB semantic model", token: str | None = None) -> dict:
    if not confirmed:
        raise ToolError("変更には --confirm が必要です。先にdry-runを確認してください。")
    # Revalidate immediately before any file change, even if a UI already displayed a plan.
    plan = sync_plan(bundle, repo, branch, expected_origin)
    visibility = verify_private_repository(expected_origin, token) if push else {"visibility": "not_checked_local_only"}
    root = Path(plan["repo"])
    touched = sorted(set(plan["added"] + plan["modified"] + plan["removed"]))
    managed_target = root / MANAGED
    managed_value = {"format_version": 1, "files": plan["files"]}
    manifest_changed = not managed_target.exists() or read_json(managed_target) != managed_value
    for path in plan["removed"]:
        ensure_no_symlinks(root, path).unlink()
    for path in plan["added"] + plan["modified"]:
        target = ensure_no_symlinks(root, path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes((Path(bundle) / "model" / path).read_bytes())
    if manifest_changed:
        write_json(managed_target, managed_value)
        touched.append(MANAGED)
    if touched:
        git(root, "add", "--", *touched)
        git(root, "commit", "-m", message, "--", *touched)
    commit = git(root, "rev-parse", "HEAD")
    if push:
        # Recheck immediately before sending bytes in case visibility changed during commit.
        visibility = verify_private_repository(expected_origin, token)
        with authentication_environment(token) as env:
            git(root, "push", "origin", "HEAD:refs/heads/" + branch, env=env)
            remote = git(root, "ls-remote", "origin", "refs/heads/" + branch, env=env)
            if not remote or remote.split()[0] != commit:
                raise ToolError("Push後のリモートHEADがローカルcommitと一致しません。OACへ進まず再確認してください。")
    return dict(commit=commit, local_commit_created=bool(touched), pushed=push,
                oac_status="NOT_SYNCED_OR_DEPLOYED", changed_files=len(touched), repository_visibility=visibility["visibility"], plan=plan)
