"""FK-based per-root stars. No guessed business joins or cross-fact measures.
Each source table keeps its own Subject Area and fact grain. Declared ancestors
become attribute dimensions; measures from ancestors are exposed only in their
own Subject Area, avoiding product-price/promotion-cost fanout across sales.
"""
from __future__ import annotations
import copy
from .core import ToolError,check_name,datatype,digest,filename,ref,table_id,NUMERIC_TYPES,oracle_type
from .validation import validate_files


def trusted(key,policy):
    return policy=='declared' or (key.get('status')=='ENABLED' and key.get('validated')=='VALIDATED') or (policy=='validated_or_rely' and key.get('rely') in (True,'RELY'))


def unique_keys(table,policy):
    actual={c['name'] for c in table['columns']}
    for key in table.get('key_constraints',[]):
        cols=key.get('columns',[])
        if not cols or len(cols)!=len(set(cols)) or not set(cols)<=actual:
            raise ToolError(f'{table_id(table)}: 宣言キーの列定義が不正です。')
    keys=[k for k in table.get('key_constraints',[]) if k.get('type') in {'P','U'} and trusted(k,policy)]
    if not keys and table.get('primary_key'):keys=[{'name':'validated_primary_key','type':'P','columns':table['primary_key'],'status':'ENABLED','validated':'VALIDATED'}]
    return sorted(keys,key=lambda k:(k.get('type')!='P',k.get('name','')))


def relationships(metadata,config):
    tables={table_id(t):t for t in metadata['tables']};edges=[];warnings=[]
    policy=config['constraint_policy']
    for ident,table in tables.items():
        columns={c['name'] for c in table['columns']};parents=set()
        for fk in sorted(table.get('foreign_keys',[]),key=lambda f:f['name']):
            target=fk['target_owner']+'.'+fk['target_table']
            if target not in tables:
                warnings.append(f'{ident}.{fk["name"]}: 参照先は対象表一覧の外にあるため結合しません。');continue
            if not trusted(fk,policy):
                warnings.append(f'{ident}.{fk["name"]}: 検証済みまたは許可されたRELY制約ではないため結合しません。');continue
            left,right=fk.get('columns',[]),fk.get('target_columns',[])
            if not left or len(left)!=len(right) or len(set(left))!=len(left) or not set(left)<=columns or not set(right)<={c['name'] for c in tables[target]['columns']}:
                raise ToolError(f'{ident}.{fk["name"]}: 外部キーの列対応が不正です。')
            candidates=[k for k in unique_keys(tables[target],policy) if k['columns']==right]
            if not candidates:
                warnings.append(f'{ident}.{fk["name"]}: 参照先の対応する主キー/一意キーを確認できないため結合しません。');continue
            if target==ident or target in parents:raise ToolError(f'{ident}: 自己参照または同じ表への複数FKにはロール別名の設計が必要です。自動推測しません。')
            parents.add(target)
            edge=dict(name=fk['name'],source=ident,target=target,columns=list(left),target_columns=list(right),target_key=candidates[0]['name'],status=fk.get('status'),validated=fk.get('validated'),rely=fk.get('rely',False),join_type='LEFT_OUTER' if any(c.get('nullable',True) for c in table['columns'] if c['name'] in left) else 'INNER')
            edges.append(edge)
            if fk.get('status')!='ENABLED' or fk.get('validated')!='VALIDATED':warnings.append(f'{ident}.{fk["name"]}: DBに宣言された関連を保持します。制約状態は{fk.get("status")}/{fk.get("validated")}であり、データ整合性の保証ではありません。' if policy=='declared' else f'{ident}.{fk["name"]}: RELY宣言を設計上信頼しますが、DB制約は{fk.get("status")}/{fk.get("validated")}です。データ整合性の保証ではありません。')
    graph={ident:[] for ident in tables}
    for e in edges:graph[e['source']].append(e)
    def walk(node,stack):
        if node in stack:raise ToolError('FKに循環があります。階層/ロールの手動設計が必要です。')
        for e in graph[node]:walk(e['target'],stack|{node})
    for ident in tables:walk(ident,set())
    return edges,warnings


def classify_measures(metadata,config):
    tables={table_id(t):t for t in metadata['tables']};rules={};report=[]
    unknown=set(config['measures'])-set(tables)
    if unknown:raise ToolError(f'measuresに対象外の表があります: {sorted(unknown)}')
    for ident,t in tables.items():
        actual={c['name'] for c in t['columns']};explicit=config['measures'].get(ident,{})
        if set(explicit)-actual:raise ToolError(f'{ident}: measuresに存在しない列があります。')
        key_columns=set(t.get('primary_key',[]))
        for k in t.get('key_constraints',[]):key_columns.update(k.get('columns',[]))
        for fk in t.get('foreign_keys',[]):key_columns.update(fk.get('columns',[]))
        for c in t['columns']:
            name=c['name'];rule=explicit.get(name);reason='explicit'
            if rule and name in key_columns:raise ToolError(f'{ident}.{name}: 関連キー列はメジャーではなく属性として保持してください。')
            if not rule and config['auto_decimal_measures'] and c['data_type']=='NUMBER' and c.get('precision') is not None and isinstance(c.get('scale'),int) and c['scale']>0 and name not in key_columns:
                rule='SUM';reason='fixed_decimal_positive_scale'
            if not rule:continue
            if rule in {'SUM','AVG'} and datatype(c['data_type']) not in NUMERIC_TYPES:raise ToolError(f'{ident}.{name}: {rule}には数値型が必要です。')
            rules[ident,name]=rule;report.append(dict(table=ident,column=name,oracle_type=oracle_type(c),rule=rule,reason=reason))
    return rules,report


def build_relationship_model(metadata,config,rows):
    tables={table_id(t):t for t in metadata['tables']};lookup={(r[2],r[3]):r for r in rows}
    edges,warnings=relationships(metadata,config);rules,measure_report=classify_measures(metadata,config)
    warnings += ['FKに沿って表ごとに独立したSubject Areaを生成します。異なるファクト粒度のメジャーは混在させません。',
        ('小数桁付きNUMBERを自動でメジャーにし、集計はSUMです。キー列は属性として保持します。' if config['constraint_policy']=='declared' and not config['measures'] else '小数桁付きNUMBERは既定でSUMメジャー、キー列は属性です。単価/比率の集計はmeasuresでAVG等を明示してください。'),
        'TRUEは論理/表示項目のみを除外します。結合キーを除外すると関連する論理結合も停止し、物理結合とDB定義は保持します。']
    db=config['database_name'];files={};paths=set();targets=set()
    def add(path,kind,body):
        if path.casefold() in paths:raise ToolError(f'SMMLファイル名が衝突しています: {path}')
        paths.add(path.casefold());files[path]={kind:body}
    add(f'physical/{filename(db)}.json','database',dict(name=db,databaseType='ORACLE_ADW',connectionPools=[dict(name=config['connection_pool'],connection=config['oac_connection'],maxConnections=10,requiresFullyQualifedTableNames=True,connectionTimeout=5,connectionTimeoutUnit='MINUTES',multithreaded=True,supportParams=True)],allowDirectDatabaseRequests=False,allowPopulateQueries=False))
    for owner in sorted({t['owner'] for t in tables.values()}):
        add(f'physical/{filename(db)}/{filename(owner)}.json','schema',{'name':owner})
    for ident,t in tables.items():
        pc=[]
        for c in t['columns']:
            col=dict(name=c['name'],dataType=datatype(c['data_type']),nullable=c.get('nullable',True))
            if c.get('length'):col['length']=c['length']
            if c.get('comment'):col['description']=c['comment']
            pc.append(col);targets.add(ref('physicalColumn',db,t['owner'],t['name'],c['name']))
        p=dict(name=t['name'],sourceType='TABLE',physicalColumns=pc,caching={'enable':False})
        if t.get('comment'):p['description']=t['comment']
        keys=unique_keys(t,config['constraint_policy'])
        if keys:p['additionalKeys']=[k['columns'] for k in keys]
        joins=[]
        for e in edges:
            if e['source']!=ident:continue
            right=tables[e['target']];objects=[];parts=[]
            for a,b in zip(e['columns'],e['target_columns']):
                objects.extend([ref('physicalColumn',db,t['owner'],t['name'],a),ref('physicalColumn',db,right['owner'],right['name'],b)])
                parts.append(f'%{len(objects)-1} = %{len(objects)}')
            joins.append(dict(rightTable=ref('physicalTable',db,right['owner'],right['name']),joinType=e['join_type'],cardinality='MANY_TO_ONE',useJoinExpression=True,joinExpression=dict(expressionTemplate=' AND '.join(parts),expressionObjects=objects)))
        if joins:p['joins']=joins
        add(f'physical/{filename(db)}/{filename(t["owner"])}/{filename(t["name"])}.json','physicalTable',p)
        targets.add(ref('physicalTable',db,t['owner'],t['name']))
    def active(ident,name):return lookup[ident,name][7]=='FALSE'
    usable=[]
    for e in edges:
        if all(active(e['source'],c) for c in e['columns']) and all(active(e['target'],c) for c in e['target_columns']):usable.append(e)
        else:warnings.append(f'{e["name"]}: キーにTRUEがあるため、論理結合だけを除外しました。')
    graph={ident:[] for ident in tables}
    for e in usable:graph[e['source']].append(e)
    logical_foreign=0;subject_count=0
    for root,t in tables.items():
        kept=[c for c in t['columns'] if active(root,c['name'])]
        if not kept:continue
        chosen=[];visited={root};queue=[root]
        while queue:
            source=queue.pop(0)
            for edge in graph[source]:
                if edge['target'] in visited:raise ToolError(f'{root}: 複数経路のFKには物理別名の設計が必要です。自動的に経路を選びません。')
                visited.add(edge['target']);chosen.append(edge);queue.append(edge['target'])
        rootrow=lookup[root,kept[0]['name']];category,root_alias=rootrow[:2]
        aliases={ident:lookup[ident,next(c['name'] for c in tables[ident]['columns'] if active(ident,c['name']))][1] for ident in visited}
        if len({a.casefold() for a in aliases.values()})!=len(aliases):raise ToolError(f'{root}: 関連する表のオブジェクト別名が重複しています。')
        bm_base=config['business_model_prefix']+' - '+root
        bm=bm_base if len(bm_base)<=128 else bm_base[:115]+'-'+digest(root)[:12]
        check_name(bm);fact_alias=root_alias[:117]+'（メジャー）'
        if fact_alias.casefold() in {a.casefold() for a in aliases.values()}:fact_alias=root_alias[:106]+'（FACT-'+digest(root)[:8]+'）'
        check_name(fact_alias)
        add(f'logical/{filename(bm)}.json','businessModel',dict(name=bm,disable=False))
        targets.add(ref('businessModel',bm))
        def lts(ident):
            tab=tables[ident]
            return [dict(name='ADB Source',tableMapping={'tables':[ref('physicalTable',db,tab['owner'],tab['name'])]})]
        def logical_column(ident,c,constant=False):
            tab=tables[ident];name=lookup[ident,c['name']][4] if not constant else c['name']
            expression={'expressionTemplate':'1','expressionObjects':[]} if constant else {'expressionTemplate':'%1','expressionObjects':[ref('physicalColumn',db,tab['owner'],tab['name'],c['name'])]}
            col=dict(name=name,dataType='NUMERIC' if constant else datatype(c['data_type']),writeable=False,logicalColumnSource={'derivedFrom':'PHYSICAL_COLUMNS','physicalMappings':[{'logicalTableSource':'ADB Source','physicalExpression':expression}]})
            if c.get('comment'):col['description']=c['comment']
            return col
        dims={};attrs={}
        for ident in sorted(visited):
            cols=[c for c in tables[ident]['columns'] if active(ident,c['name']) and (ident,c['name']) not in rules]
            attrs[ident]=cols
            synthetic=not cols
            actual_cols=[logical_column(ident,c) for c in cols] if cols else [logical_column(ident,{'name':'技術メンバー'},constant=True)]
            candidates=[k for k in unique_keys(tables[ident],config['constraint_policy']) if all(c in {a['name'] for a in cols} for c in k['columns'])]
            pk=[lookup[ident,c][4] for c in candidates[0]['columns']] if candidates else [c['name'] for c in actual_cols]
            dim=dict(name=aliases[ident],type='DIMENSION',logicalColumns=actual_cols,logicalTableSources=lts(ident),primaryKey=pk)
            dim['description']='DBの宣言キー（制約状態は別途検証）' if candidates else '属性組合せの技術メンバーキー。物理行の一意性を宣言しません。'
            dims[ident]=dim;targets.add(ref('logicalTable',bm,aliases[ident]))
            for c in actual_cols:targets.add(ref('logicalColumn',bm,aliases[ident],c['name']))
        fact_cols=[]
        for c in kept:
            if (root,c['name']) in rules:
                col=logical_column(root,c);col['aggregation']={'rule':rules[root,c['name']]};fact_cols.append(col)
        count=logical_column(root,{'name':config['row_count_name']},constant=True);count['aggregation']={'rule':'SUM'};fact_cols.append(count)
        fact=dict(name=fact_alias,type='FACT',logicalColumns=fact_cols,logicalTableSources=lts(root),joins=[dict(rightTable=ref('logicalTable',bm,aliases[root]),joinType='INNER',cardinality='MANY_TO_ONE')])
        for e in chosen:
            parent=ref('logicalTable',bm,aliases[e['target']]);join=dict(rightTable=parent,joinType=e['join_type'],cardinality='MANY_TO_ONE')
            if e['source']==root:fact['joins'].append(join)
            else:dims[e['source']].setdefault('joins',[]).append(join)
            logical_foreign+=1
        add(f'logical/{filename(bm)}/{filename(fact_alias)}.json','logicalTable',fact)
        targets.add(ref('logicalTable',bm,fact_alias))
        for c in fact_cols:targets.add(ref('logicalColumn',bm,fact_alias,c['name']))
        for ident,dim in dims.items():add(f'logical/{filename(bm)}/{filename(dim["name"])}.json','logicalTable',dim)
        add(f'presentation/{filename(category)}.json','subjectArea',dict(name=category,sourceBusinessModel=ref('businessModel',bm),implicitFactColumn=ref('logicalColumn',bm,fact_alias,config['row_count_name'])))
        targets.add(ref('subjectArea',category));subject_count+=1
        for ident in sorted(visited):
            presentation=[]
            for c in (kept if ident==root else attrs[ident]):
                name=lookup[ident,c['name']][4];source_alias=fact_alias if ident==root and (ident,c['name']) in rules else aliases[ident]
                presentation.append(dict(name=name,sourceLogicalColumn=ref('logicalColumn',bm,source_alias,name)))
            if ident==root:presentation.append(dict(name=config['row_count_name'],sourceLogicalColumn=ref('logicalColumn',bm,fact_alias,config['row_count_name'])))
            if presentation:
                add(f'presentation/{filename(category)}/{filename(aliases[ident])}.json','presentationTable',dict(name=aliases[ident],presentationColumns=presentation))
    def check(value,field=None):
        if isinstance(value,dict):
            for k,v in value.items():check(v,k)
        elif isinstance(value,list):
            for item in value:check(item,field)
        elif isinstance(value,str) and field in {'rightTable','drivingTable','expressionObjects','tables','sourceBusinessModel','sourceLogicalColumn','implicitFactColumn'} and value not in targets:
            raise ToolError(f'SMML参照先がありません: {value}')
    check(files)
    validation=validate_files(files);validation['reference_integrity']='passed'
    active_count=sum(r[7]=='FALSE' for r in rows)
    active_measures=[r for r in measure_report if active(r['table'],r['column'])]
    return dict(metadata=metadata,config=config,review=rows,files=files,warnings=warnings,validation=validation,
        relationships=edges,measure_classification=active_measures,
        stats=dict(physical_tables=len(tables),source_columns=len(rows),active_source_columns=active_count,deleted_semantic_columns=len(rows)-active_count,subject_areas=subject_count,physical_foreign_keys=len(edges),logical_foreign_key_joins=logical_foreign,measure_columns=len(active_measures)))
