"""Japanese customer entry point. CLI needs no web stack; GUI is optional."""
from __future__ import annotations
import contextlib
import getpass
import importlib.resources
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime
from . import cli
from .adb import extract_configured
from .bundle import save_bundle
from .ui_config import customer_generation_config
from .core import ToolError
from .generator import build_model
from .git_sync import authentication_environment, apply_sync, sync_plan
from .privacy import verify_private_repository


@contextlib.contextmanager
def temporary_secrets(values):
    previous={key:os.environ.get(key) for key in values}
    try:
        os.environ.update({k:v for k,v in values.items() if v})
        yield
    finally:
        for key,value in previous.items():
            if value is None:os.environ.pop(key,None)
            else:os.environ[key]=value


def prompt(text,default=''):
    value=input(text+(f' [{default}]' if default else '')+': ').strip()
    return value or default


def launch_ui(home: Path, extra: list[str]) -> int:
    try:
        import importlib.util
        if importlib.util.find_spec('streamlit') is None:
            raise ToolError('画面版にはstreamlitが必要です。画面版パッケージのrequirements.txtから依存関係を導入してください。')
        asset=importlib.resources.files('smml_tool').joinpath('data/app.py').read_bytes()
        runtime=home/'.runtime/smml-ui';runtime.mkdir(parents=True,exist_ok=True)
        script=runtime/'app.py';script.write_bytes(asset)
        env=os.environ.copy();env['ADB_SMML_HOME']=str(home)
        return subprocess.call([sys.executable,'-m','streamlit','run',str(script),'--server.address','127.0.0.1','--server.port','8501','--browser.gatherUsageStats','false','--client.toolbarMode','minimal',*extra],cwd=home,env=env)
    except (ToolError,OSError) as error:
        print('エラー：'+str(error),file=sys.stderr);return 2


def main():
    home=Path(sys.argv[0]).resolve().parent
    if len(sys.argv)>1:
        if sys.argv[1]=='ui':return launch_ui(home,sys.argv[2:])
        return cli.main()
    print('ADB SMML 日本語版 非公開GitHub専用')
    print('1  ADBからモデルとExcelを生成\n2  Excelの変更をモデルに反映\n3  非公開GitHubへ同期\n4  モデルを検証\n0  終了')
    operation=prompt('操作を選択','0')
    if operation=='0':return 0
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S')
    try:
        if operation in {'1','3'}:
            cfg_path=Path(prompt('設定ファイル',str(home/'settings.json'))).expanduser().resolve();config=cli.load_config(cfg_path)
        if operation=='1':
            config=customer_generation_config(config)
            db=config['db'];model=config['model']
            user=prompt('ADBユーザー名',os.environ.get(db.get('user_env','ADB_USER')) or config.get('ui',{}).get('adb_username','admin'))
            existing=os.environ.get(db.get('password_env','ADB_PASSWORD'),'')
            password=getpass.getpass('ADBパスワード'+(' 空欄で環境変数の設定値を使用' if existing else '')+': ') or existing
            wallet_password=''
            if db.get('transport','oracle')=='oracle' and db.get('wallet'):
                wallet_password=getpass.getpass('Walletパスワード 必要な場合のみ: ') or os.environ.get(db.get('wallet_password_env','ADB_WALLET_PASSWORD'),'')
            db['schema']=prompt('ADBスキーマ',db['schema'])
            db['tables']=[t.strip() for t in prompt('対象テーブル一覧 カンマ区切り',','.join(db['tables'])).split(',') if t.strip()]
            model['oac_connection']=prompt('OACデータ接続参照',model['oac_connection'])
            model['database_name']=prompt('物理データベース名',model['database_name'])
            model['subject_area_prefix']=prompt('サブジェクト領域名',model['subject_area_prefix'])
            output=prompt('出力フォルダー',str(home/'outputs'/('initial-'+stamp)))
            metadata=extract_configured(db,dict(user=user,password=password,wallet_password=wallet_password));password=wallet_password=None
            result=save_bundle(build_model(metadata,model),output,oac_url=config.get('oac',{}).get('url',''))
        elif operation=='2':
            baseline=prompt('元モデルのフォルダー manifest.jsonを含む')
            excel=prompt('変更した確認用Excel')
            output=prompt('更新版の出力フォルダー',str(home/'outputs'/('updated-'+stamp)))
            result=cli.run(cli.parser().parse_args(['apply','--baseline',baseline,'--excel',excel,'--out',output]))
        elif operation=='3':
            github=config.get('github',{});origin=github.get('origin') or prompt('GitHub HTTPSリポジトリURL')
            branch=github.get('branch','main');raw=Path(github.get('repo','model-repo')).expanduser();repo=raw if raw.is_absolute() else cfg_path.parent/raw
            bundle=prompt('同期するモデルのフォルダー')
            token=os.environ.get('GITHUB_TOKEN') or getpass.getpass('GitHub Token この処理のメモリー内のみ: ')
            private=verify_private_repository(origin,token);print(private['repository']+' が非公開であることを検証しました。')
            if not repo.exists():
                with authentication_environment(token) as env:
                    process=subprocess.run(['git','clone','--',origin,str(repo)],env=env,text=True,capture_output=True,timeout=180)
                if process.returncode:raise ToolError('クローンに失敗しました。権限とネットワークを確認してください。'+process.stderr.replace(token,'[REDACTED]')[:400])
            plan=sync_plan(bundle,repo,branch,origin);print(json.dumps({k:v for k,v in plan.items() if k!='files'},ensure_ascii=False,indent=2))
            if prompt('コミットとプッシュを許可する場合のみ PUSH と入力','NO')!='PUSH':
                print('キャンセルしました。モデル用Git作業フォルダーは変更していません。');return 0
            result=apply_sync(bundle,repo,branch,origin,confirmed=True,push=True,token=token);token=None
        elif operation=='4':result=cli.run(cli.parser().parse_args(['validate',prompt('検証するモデルのフォルダー')]))
        else:raise ToolError('不明な操作です。')
        print('処理が完了しました。OACへのデプロイは実行していません。')
        print(json.dumps(result,ensure_ascii=False,indent=2));return 0
    except (ToolError,OSError,ValueError,KeyError) as error:
        print('エラー：'+str(error),file=sys.stderr);return 2
    except Exception as error:
        print(f'エラー：{type(error).__name__}。本機の接続と設定を確認してください。OACへのデプロイは続行していません。',file=sys.stderr);return 3
