"""Read only dictionary extraction over the documented ORDS REST-enabled SQL API.

This optional HTTPS transport needs neither an Oracle client nor a Wallet. It never
uses browser cookies or saved OAC credentials. One SELECT provides one consistent
statement-level snapshot, including actual validated PK/FK definitions.
"""
from __future__ import annotations

import base64
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone

from .core import ToolError, validate_metadata

MAX_RESPONSE = 32 * 1024 * 1024


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Never forward the database Authorization header to a redirected host.
        raise ToolError("ORDSリダイレクトを拒否しました。HTTPSエンドポイントを確認してください。")


def _validate_endpoint(value: str) -> str:
    try:
        url = urllib.parse.urlsplit(value)
        valid = (url.scheme == "https" and url.hostname and not url.username
                 and not url.password and not url.query and not url.fragment
                 and url.port in (None, 443)
                 and re.fullmatch(r"/ords/[A-Za-z0-9_.~-]+/_/sql/?", url.path))
    except (ValueError, TypeError):
        valid = False
    if not valid:
        raise ToolError("ords_urlは認証情報とクエリーパラメーターを含まないHTTPS /ords/<schema>/_/sql エンドポイントで指定してください。")
    return value


def _post_dictionary(endpoint: str, sql: str, binds: list[dict], user: str, password: str) -> list[dict]:
    # This private helper accepts only the generated dictionary SELECT, never UI SQL.
    if not sql.lstrip().lower().startswith("select ") or ";" in sql:
        raise ToolError("ORDSではツールが生成した単一の読取り専用定義SELECTのみ使用できます。")
    payload = json.dumps({"statementText": sql, "binds": binds, "limit": 10000}).encode()
    authorization = base64.b64encode((user + ":" + password).encode()).decode()
    request = urllib.request.Request(_validate_endpoint(endpoint), data=payload, method="POST",
        headers={"Content-Type": "application/json", "Accept": "application/json", "Authorization": "Basic " + authorization})
    try:
        with urllib.request.build_opener(_NoRedirect()).open(request, timeout=60) as response:
            raw = response.read(MAX_RESPONSE + 1)
            if len(raw) > MAX_RESPONSE:
                raise ToolError("ORDSの応答が大きすぎます。対象テーブルを減らしてください。")
        data = json.loads(raw)
    except urllib.error.HTTPError as error:
        # Server messages can echo SQL/credentials; expose only the status number.
        raise ToolError(f"ORDS要求に失敗しました（HTTP {error.code}）。エンドポイントとアクセス権限を確認してください。") from None
    except (OSError, ValueError, urllib.error.URLError):
        raise ToolError("ORDS接続またはJSON応答が不正です。生成と同期は続行していません。") from None
    finally:
        authorization = password = request = None
    statements = data.get("items", [])
    if len(statements) != 1 or statements[0].get("statementType") != "query" or statements[0].get("result") != 0 or statements[0].get("errorCode"):
        raise ToolError("ORDSの定義SELECTが失敗しました。モデルは生成していません。")
    result = statements[0].get("resultSet", {})
    rows = result.get("items")
    if (not isinstance(rows, list) or result.get("hasMore") is not False
            or result.get("offset") != 0 or result.get("count") != len(rows)):
        raise ToolError("ORDSの定義結果が不完全かページ分割されています。対象テーブルを減らしてください。")
    return rows


def extract_ords(db_config: dict, secrets: dict | None = None) -> dict:
    secrets = secrets or {}
    user = secrets.get("user") or os.environ.get(db_config.get("user_env", "ADB_USER"))
    password = secrets.get("password") or os.environ.get(db_config.get("password_env", "ADB_PASSWORD"))
    if not user or not password:
        raise ToolError("ADB_USERとADB_PASSWORDを本機で設定してください。設定ファイルには認証情報を保存しないでください。")
    owner, tables = db_config.get("schema"), db_config.get("tables")
    if (not isinstance(owner, str) or not owner or not isinstance(tables, list) or not tables
            or any(not isinstance(t, str) or not t for t in tables) or len(tables) != len(set(tables))):
        raise ToolError("スキーマと重複のない対象テーブル一覧を指定してください。")
    binds = [{"name": "owner", "data_type": "VARCHAR2", "value": owner}]
    binds.extend({"name": f"t{i}", "data_type": "VARCHAR2", "value": t} for i, t in enumerate(tables))
    placeholders = ",".join(f":t{i}" for i in range(len(tables)))
    # The only interpolated SQL tokens are generated placeholder indexes / fixed literals.
    types = "'TABLE','VIEW'" if db_config.get("include_views", False) else "'TABLE'"
    sql = f"""select c.owner,c.table_name,t.table_type,t.comments as table_comment,
 c.column_name,c.data_type,c.data_length as byte_length,c.char_length,c.char_used,
 c.data_precision,c.data_scale,c.nullable,m.comments as column_comment,c.column_id,
 sys_context('USERENV','DB_NAME') as database_name,
 sys_context('USERENV','CURRENT_SCHEMA') as session_schema,
 sys_context('USERENV','CON_NAME') as container_name,
 sys_context('USERENV','SERVICE_NAME') as service_name,
 (select json_arrayagg(json_object(
  'name' value k.constraint_name,'type' value k.constraint_type,'column' value cc.column_name,
  'position' value cc.position,'target_owner' value k.r_owner,'target_table' value p.table_name,
  'target_column' value pc.column_name,'status' value k.status,'validated' value k.validated,'rely' value k.rely)
  order by k.constraint_name,cc.position returning clob)
  from all_constraints k join all_cons_columns cc
   on cc.owner=k.owner and cc.constraint_name=k.constraint_name
  left join all_constraints p on p.owner=k.r_owner and p.constraint_name=k.r_constraint_name
  left join all_cons_columns pc on pc.owner=p.owner and pc.constraint_name=p.constraint_name and pc.position=cc.position
  where k.owner=c.owner and k.table_name=c.table_name and k.constraint_type in ('P','R','U')) as keys_json
from all_tab_columns c
join all_tab_comments t on t.owner=c.owner and t.table_name=c.table_name and t.table_type in ({types})
left join all_col_comments m on m.owner=c.owner and m.table_name=c.table_name and m.column_name=c.column_name
where c.owner=:owner and c.table_name in ({placeholders})
order by c.table_name,c.column_id"""
    rows = _post_dictionary(db_config.get("ords_url", ""), sql, binds, user, password)
    password = None
    if not rows:
        raise ToolError("指定した表が存在しないか、定義の読取り権限がありません。")
    identity = {k: rows[0][k] for k in ("database_name", "session_schema", "container_name", "service_name")}
    expected = db_config.get("expected_database")
    if expected and identity["database_name"] != expected:
        raise ToolError("ORDSの接続先DBとexpected_databaseが不一致です。この定義スナップショットは使用しません。")
    output = {}
    for r in rows:
        if r["owner"] != owner or r["table_name"] not in tables or any(r[k] != v for k, v in identity.items()):
            raise ToolError("ORDSの定義結果が指定範囲外か、接続先DBが不一致です。")
        t = output.get(r["table_name"])
        if t is None:
            keys = json.loads(r["keys_json"]) if r["keys_json"] else []
            from .adb import key_metadata
            t = output[r["table_name"]] = dict(owner=owner, name=r["table_name"], comment=r["table_comment"],
                object_type=r["table_type"], columns=[], **key_metadata(keys))
        character = r["data_type"] in ("CHAR", "NCHAR", "VARCHAR2", "NVARCHAR2")
        length = r["char_length"] if character and r["char_used"] in ("C", "B") else r["byte_length"] if r["data_type"] == "RAW" else 0
        t["columns"].append(dict(name=r["column_name"], data_type=r["data_type"], length=length or 0,
            byte_length=r["byte_length"], char_used=r["char_used"], precision=r["data_precision"], scale=r["data_scale"],
            nullable=r["nullable"] == "Y", comment=r["column_comment"], ordinal=r["column_id"]))
    if set(output) != set(tables):
        raise ToolError("ORDSの結果に指定した表が不足しています。一部の表だけでは生成しません。")
    for t in output.values():
        if [c["ordinal"] for c in t["columns"]] != list(range(1, len(t["columns"]) + 1)):
            raise ToolError("ORDSの列順序が不連続です。欠落の可能性がある結果は使用しません。")
    return validate_metadata(dict(format_version=1, source="adb_dictionary_read_only", transport="ords_rest_enabled_sql",
        database=identity["database_name"], session_schema=identity["session_schema"], container=identity["container_name"],
        service=identity["service_name"], captured_at=datetime.now(timezone.utc).isoformat(),
        consistency="single_dictionary_select", tables=list(output.values())))
