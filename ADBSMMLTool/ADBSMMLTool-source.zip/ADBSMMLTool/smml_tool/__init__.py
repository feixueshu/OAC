"""ADB → SMML → Excel review → SMML. No database data writes."""
__version__ = "0.1.0"
