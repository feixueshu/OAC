from __future__ import annotations

import json
from contextlib import closing
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

from openpyxl import load_workbook

from .core import HEADERS, ToolError

ROOT = Path(__file__).resolve().parents[1]
INSTRUCTIONS = [
    ["ADB → SMML → Excel review", "操作ガイド"],
    ["1. 初期モデル", "ADBのCOMMENTを論理層・表示層の名称として使い、先にSMMLを生成します。"],
    ["2. 編集できる列", "A: カテゴリ別名 / B: オブジェクト別名 / E: アイテム別名 / H: 削除フラグ"],
    ["3. 変更禁止の列", "C: テーブル名 / D: カラム名 / F: 属性 / G: サイズ。物理識別子です。"],
    ["4. 削除フラグ", "TRUE = 論理層・表示層から除外。FALSE = 保持。Excelの論理値TRUE/FALSEも使用できます。"],
    ["5. データは削除しません", "ADBの表・列・データ、SMMLの物理層は削除しません。"],
    ["6. 行を削除しない", "行の削除/追加はエラーです。削除したい列はH列でTRUEを選択してください。"],
    ["7. テーブル別名", "同一テーブルのA/B列は全行同じ名前にしてください。複数の物理表を同じカテゴリに統合できません。"],
    ["8. 同名チェック", "同一テーブル内のアイテム別名を重複させないでください。名前は1〜128文字です。"],
    ["9. 元モデルとの対応", "以前のExcelも、テーブル名・カラム名・定義が一致すれば使用できます。行を削除せず、削除フラグを使ってください。"],
    ["10. 自動行数", "各表にSUM(1)の「行数（自動生成）」を追加します。DB列ではなく、この一覧には含みません。"],
    ["11. 集計と結合", "V1は単表モデルです。Joinは推測せず、通常の数値列にも勝手にSUMを設定しません。"],
    ["12. OAC反映", "Git pushだけでは反映されません。OACでPull → 一貫性チェック → Deployを実施してください。"],
    ["13. 再編集", "更新後モデルに再取り込みする場合は、そのモデルから出力した新しいExcelを使用してください。"],
]


def payload_for(model: dict) -> dict:
    instructions = [list(row) for row in INSTRUCTIONS]
    if model["config"].get("strategy") == "single_table_star":
        instructions[11][1] = "1物理表→属性表+集計表。同一物理表を共有します。表をまたぐJoinや通常数値列のSUMは推測しません。"
    if model['config'].get('strategy')=='foreign_key_star':
        instructions[7][1]='A列は各表のSubject Area名、B列は関連する全モデル内の表別名です。同じ表の全行を統一します。'
        instructions[11][1]='DBのFKとキーから関連モデルを生成。小数NUMBERはメジャー、キーは属性。別粒度のメジャーは各表のSubject Areaに分離します。'
        instructions[12][1]='Git push後にOACでPull、整合性チェック、Advanced Checkを行い、確認後に手動Deployします。'
        instructions.append(['14. 結合キーの除外','キー列をTRUEにすると、その論理結合も除外して警告します。物理層・DB定義は変更しません。'])
    if model['config'].get('subject_area_layout')=='single':
        instructions[7][1]='A列は単一Subject Area名で、全表の全行を同じ名前にします。B列は表別名で、同一表の全行を統一し、他の表と重複させません。'
        instructions[11][1]='全表を1つのSubject Areaへ配置。宣言済みFKと共通ディメンションを保持し、ファクト同士の直接結合は追加しません。メジャーはSUMです。'
    return {"headers": HEADERS, "rows": model["review"], "instructions": instructions}


def artifact_runtime() -> tuple[str, Path] | None:
    # Customer zipapp intentionally ships no Node/Codex/Artifact runtime.
    if not ROOT.is_dir():
        return None
    configured = os.environ.get("ADB_SMML_ARTIFACT_MODULES")
    modules = Path(configured).expanduser() if configured else Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules"
    node = os.environ.get("ADB_SMML_NODE") or str(modules.parent / "bin/node")
    if not Path(node).is_file():
        node = shutil.which("node") or ""
    if node and (modules / "@oai/artifact-tool").is_dir():
        link = ROOT / "node_modules"
        if not link.exists():
            link.symlink_to(modules, target_is_directory=True)
        if link.resolve() != modules.resolve():
            raise ToolError("node_modulesは指定したArtifact runtimeと異なります。ADB_SMML_ARTIFACT_MODULESを確認してください。")
        return node, modules
    if configured:
        raise ToolError("指定した Artifact runtime が見つかりません。")
    return None


def export_workbook(model: dict, output: Path, preview: bool = False) -> str:
    payload = payload_for(model)
    runtime = artifact_runtime()
    if runtime:
        with tempfile.TemporaryDirectory(prefix="smml-excel-") as temp:
            source = Path(temp) / "payload.json"
            source.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            args = [runtime[0], str(ROOT / "scripts/workbook.mjs"), str(source), str(output)]
            if preview:
                args.append(str(output.with_suffix(".preview.png")))
            result = subprocess.run(args, text=True, capture_output=True, timeout=180)
            if result.returncode:
                raise ToolError("Excel生成に失敗: " + (result.stderr or result.stdout)[-2500:])
        return "artifact-tool"
    # Standalone customer installs do not ship Codex's private Artifact runtime.
    # Use the portable backend ONLY when that runtime is absent.
    _portable_export(payload, output)
    return "openpyxl-portable-runtime-absent"



def _portable_export(payload: dict, output: Path) -> None:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.worksheet.table import Table, TableStyleInfo
    from openpyxl.formatting.rule import FormulaRule
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "テーブル一覧"
    sheet.append(payload["headers"])
    for row in payload["rows"]:
        sheet.append(row)
        for cell in sheet[sheet.max_row]:
            # OOXML explicit string type, never interpret text as a formula.
            if isinstance(cell.value, str):
                cell.data_type = "s"
    widths = [30, 44, 26, 28, 44, 16, 12, 18]
    for letter, width in zip("ABCDEFGH", widths):
        sheet.column_dimensions[letter].width = width
    for row in sheet:
        for cell in row:
            cell.font = Font(name="Yu Gothic", size=11)
            cell.alignment = Alignment(vertical="center", wrap_text=True)
        sheet.row_dimensions[row[0].row].height = 42
    for cell in sheet[1]:
        cell.fill = PatternFill("solid", fgColor="23374D")
        cell.font = Font(name="Yu Gothic", bold=True, color="FFFFFF", size=11)
    sheet.freeze_panes = "E2"
    end = sheet.max_row
    for cell in sheet['H'][1:]:cell.number_format='@'
    if end >= 2:
        table = Table(displayName="DataItems", ref=f"A1:H{end}")
        table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
        sheet.add_table(table)
        validation = DataValidation(type="list", formula1='"TRUE,FALSE"', allow_blank=False)
        validation.errorTitle = "削除フラグ"
        validation.error = "TRUE または FALSE を選択してください。"
        validation.showErrorMessage = True
        validation.errorStyle = "stop"
        sheet.add_data_validation(validation)
        validation.add(f"H2:H{end}")
        sheet.conditional_formatting.add(f"A2:H{end}", FormulaRule(formula=['OR($H2=TRUE,$H2="TRUE")'], fill=PatternFill("solid", fgColor="FDE9E7")))
    for title, rows in (("使い方", payload["instructions"]),):
        target = workbook.create_sheet(title)
        for row in rows:
            target.append(row)
        target.column_dimensions["A"].width = 32
        target.column_dimensions["B"].width = 110
        for row in target:
            for cell in row:
                cell.alignment = Alignment(wrap_text=True, vertical="center")
                cell.font = Font(name="Yu Gothic", size=11)
            target.row_dimensions[row[0].row].height = 44
    workbook.save(output)


def read_review(path: str | Path, baseline: dict) -> list[list]:
    with zipfile.ZipFile(path) as archive:
        if len(archive.infolist()) > 1000 or sum(i.file_size for i in archive.infolist()) > 128 * 1024 * 1024:
            raise ToolError("Excel ZIPの展開サイズが大きすぎます。")
    with closing(load_workbook(path, read_only=True, data_only=False, keep_links=False)) as workbook:
        if "テーブル一覧" not in workbook.sheetnames:
            raise ToolError("テーブル一覧シートがありません。このツールの8列形式のExcelを選択してください。")
        # Batch hashes in old 管理情報 sheets are intentionally ignored. Physical
        # identifiers and current definitions below are the compatibility boundary.
        sheet = workbook["テーブル一覧"]
        if (sheet.max_row or 0) > 200_001 or (sheet.max_column or 0) > 32:
            raise ToolError("Excelが大きすぎます（上限20万行）。")
        records = sheet.iter_rows()
        first = next(records, ())
        if [c.value for c in first[:8]] != HEADERS or any(c.value is not None for c in first[8:]):
            raise ToolError("ヘッダーは元の8列を保ってください。")
        result = []
        for index, row in enumerate(records, 2):
            if index > 200_001 or len(row) > 32:
                raise ToolError("Excelが大きすぎます。")
            if all(c.value is None for c in row):
                continue
            if any(c.data_type == "f" for c in row) or any(c.value is not None for c in row[8:]):
                raise ToolError(f"Excel {index}行: 数式/追加列は許可されていません。")
            values=[c.value for c in row[:8]]
            result.append(values)
        from .generator import check_review
        return check_review(baseline["metadata"],baseline["config"],result)
