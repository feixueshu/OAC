"""Non-secret, editable defaults shared by the Japanese UI and customer launcher."""
from __future__ import annotations

import copy
import os
from pathlib import Path
from urllib.parse import urlsplit, parse_qsl
from .core import ToolError, model_config

DB_FIELDS = {'dsn','wallet','user_env','password_env','wallet_password_env','schema','tables','include_views','transport','ords_url','expected_database'}


def config_path(home: Path) -> Path:
    configured = os.environ.get('ADB_SMML_CONFIG')
    if configured:
        return Path(configured).expanduser().resolve()
    return home/'settings.json' if (home/'settings.json').is_file() else home/'examples/config.example.json'


def validate_public_config(config: dict) -> None:
    """Passwords/tokens are forbidden, including in new UI defaults sections."""
    def walk(value):
        if isinstance(value, dict):
            for key, child in value.items():
                lowered=key.lower()
                if lowered in {'password','wallet_password','token','github_token','access_token','adb_password','secret'}:
                    raise ToolError('設定ファイルにパスワードやTokenは保存できません。画面入力または環境変数を使用してください。')
                walk(child)
        elif isinstance(value,list):
            for child in value:walk(child)
    # A model measures map contains physical column names, not credentials.
    for section,value in config.items():
        if section != 'model':walk({section:value})
    for section,keys in [('db',['ords_url']),('oac',['url','workspace_url']),('github',['origin'])]:
        for key in keys:
            text=config.get(section,{}).get(key,'')
            if isinstance(text,str) and text.startswith(('https://','http://')):
                parsed=urlsplit(text)
                if parsed.username or parsed.password or any(k.lower() in {'token','access_token','password','pwd'} for k,_ in parse_qsl(parsed.query)):
                    raise ToolError('接続URLに認証情報を埋め込むことはできません。パスワードとTokenは専用の入力欄を使用してください。')
    display_name=config.get('oac',{}).get('connection_display_name','')
    if not isinstance(display_name,str) or len(display_name)>256:
        raise ToolError('OAC接続表示名は256文字以内の文字列で指定してください。')
    ui=config.get('ui',{})
    if not isinstance(ui,dict) or set(ui)-{'language','adb_username','data_source'}:
        raise ToolError('ui設定はlanguage、adb_username、data_sourceのみ指定できます。')
    if not isinstance(ui.get('adb_username','admin'),str):
        raise ToolError('ADBユーザー名の既定値は文字列で指定してください。')
    if ui.get('data_source','live') not in {'live','offline'}:
        raise ToolError('data_sourceはliveまたはofflineで指定してください。')


def export_public_config(config: dict, *, username: str, wallet: str | None = None) -> dict:
    """Whitelist an export; never serialize widget state, secret inputs, or env."""
    result={'db':{k:copy.deepcopy(v) for k,v in config['db'].items() if k in DB_FIELDS},
            'model':model_config(config['model']),
            'ui':{'language':'ja','adb_username':username.strip(),'data_source':'live'},
            'oac':{k:config.get('oac',{}).get(k,'') for k in ['url','workspace_url','connection_display_name']}}
    if not result['model'].get('measures'):result['model'].pop('measures',None)
    if wallet is not None:result['db']['wallet']=wallet
    if 'github' in config:
        result['github']={k:config['github'].get(k,'') for k in ['origin','branch','repo']}
    validate_public_config(result)
    return result


def customer_generation_config(config: dict) -> dict:
    """Fixed rules for new customer models; historical bundles are never migrated."""
    validate_public_config(config)
    result=copy.deepcopy(config)
    result.setdefault('db',{})['include_views']=True
    model=result.setdefault('model',{})
    model.update(strategy='foreign_key_star',auto_decimal_measures=True,constraint_policy='declared',subject_area_layout='single')
    model.pop('measures',None)  # Every automatically classified measure uses SUM.
    result.setdefault('ui',{}).pop('data_source',None)
    return result


def require_customer_model(model: dict) -> None:
    """Do not silently carry historical AVG/custom-policy bundles into the new UI."""
    c=model['config']
    if (c.get('strategy')!='foreign_key_star' or not c.get('auto_decimal_measures')
            or c.get('constraint_policy')!='declared' or c.get('measures') or c.get('subject_area_layout')!='single'):
        raise ToolError('旧版の生成規則を含むモデルです。新しいモデルを生成し、その確認用Excelを使用してください。元モデルは変更しません。')


def same_origin(a: str, b: str) -> bool:
    try:
        x,y=urlsplit(a),urlsplit(b)
        return x.scheme=='https' and y.scheme=='https' and (x.hostname,x.port)==(y.hostname,y.port)
    except (ValueError,TypeError):
        return False
