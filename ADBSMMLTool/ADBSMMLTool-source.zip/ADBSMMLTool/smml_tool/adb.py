from __future__ import annotations

import contextlib
import os
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from .core import ToolError, validate_metadata

# Fixed dictionary queries with bind variables. No user-provided SQL is executed.
TABLES_SQL = """
select t.owner, t.table_name, c.comments
from all_tables t left join all_tab_comments c
 on c.owner=t.owner and c.table_name=t.table_name and c.table_type='TABLE'
where t.owner=:owner and t.nested='NO' and t.secondary='N'
order by t.table_name
"""
VIEWS_SQL = """
select v.owner, v.view_name, c.comments
from all_views v left join all_tab_comments c
 on c.owner=v.owner and c.table_name=v.view_name and c.table_type='VIEW'
where v.owner=:owner order by v.view_name
"""
COLUMNS_SQL = """
select c.column_name, c.data_type, c.data_length, c.char_length, c.char_used,
       c.data_precision, c.data_scale, c.nullable, m.comments, c.column_id
from all_tab_columns c left join all_col_comments m
 on m.owner=c.owner and m.table_name=c.table_name and m.column_name=c.column_name
where c.owner=:owner and c.table_name=:table_name order by c.column_id
"""
KEYS_SQL = """
select c.constraint_name, c.constraint_type, cc.column_name, cc.position,
       c.r_owner, p.table_name, pc.column_name, c.status, c.validated, c.rely
from all_constraints c
join all_cons_columns cc on cc.owner=c.owner and cc.constraint_name=c.constraint_name
left join all_constraints p on p.owner=c.r_owner and p.constraint_name=c.r_constraint_name
left join all_cons_columns pc
 on pc.owner=p.owner and pc.constraint_name=p.constraint_name and pc.position=cc.position
where c.owner=:owner and c.table_name=:table_name and c.constraint_type in ('P','R','U')
order by c.constraint_name, cc.position
"""


def key_metadata(rows: list[dict]) -> dict:
    """Retain declared keys and RELY separately from DB-enforced validated PKs."""
    grouped={}
    for row in rows:
        key=grouped.setdefault(row['name'],{'name':row['name'],'type':row['type'],'columns':[],
            'status':row.get('status','UNKNOWN'),'validated':row.get('validated','UNKNOWN'),
            'rely':row.get('rely') in ('RELY',True)})
        key['columns'].append((row['position'],row['column']))
        if row['type']=='R':
            key.update(target_owner=row['target_owner'],target_table=row['target_table'])
            key.setdefault('target_columns',[]).append((row['position'],row['target_column']))
    keys=[];foreign=[];primary=[]
    for name,key in sorted(grouped.items()):
        key['columns']=[v for _,v in sorted(key['columns'])]
        if key['type']=='R':
            key['target_columns']=[v for _,v in sorted(key['target_columns'])]
            foreign.append({k:v for k,v in key.items() if k!='type'})
        else:
            keys.append(key)
            if key['type']=='P' and key['status']=='ENABLED' and key['validated']=='VALIDATED':primary=key['columns']
    return dict(primary_key=primary,foreign_keys=foreign,key_constraints=keys)


@contextlib.contextmanager
def wallet_directory(path: str | Path | None):
    if not path:
        yield None
        return
    source = Path(path).expanduser().resolve()
    if source.is_dir():
        yield str(source)
        return
    if not source.is_file():
        raise ToolError(f"Walletが見つかりません: {source}")
    with tempfile.TemporaryDirectory(prefix="adb-wallet-") as temp:
        os.chmod(temp, 0o700)
        with zipfile.ZipFile(source) as archive:
            for info in archive.infolist():
                # Wallet contents never enter outputs or the Git staging directory.
                if info.is_dir():
                    continue
                if info.filename != Path(info.filename).name or "\\" in info.filename or info.file_size > 2_000_000:
                    raise ToolError("Wallet ZIPに不正なパスまたは過大なファイルがあります。")
                target = Path(temp) / info.filename
                target.write_bytes(archive.read(info))
                target.chmod(0o600)
        yield temp


@contextlib.contextmanager
def connect(db_config: dict, secrets: dict | None = None):
    import oracledb
    secrets = secrets or {}
    user = secrets.get("user") or os.environ.get(db_config.get("user_env", "ADB_USER"))
    password = secrets.get("password") or os.environ.get(db_config.get("password_env", "ADB_PASSWORD"))
    wallet_password = secrets.get("wallet_password") or os.environ.get(db_config.get("wallet_password_env", "ADB_WALLET_PASSWORD"))
    if not user or not password:
        raise ToolError("ADB_USERとADB_PASSWORDを本機で設定してください。認証情報をチャットや設定ファイルに保存しないでください。")
    if not db_config.get("dsn"):
        raise ToolError("db.dsn が必要です。")
    with wallet_directory(db_config.get("wallet")) as wallet:
        kwargs = dict(user=user, password=password, dsn=db_config["dsn"], tcp_connect_timeout=15)
        if wallet:
            kwargs.update(config_dir=wallet, wallet_location=wallet)
            if wallet_password:
                kwargs["wallet_password"] = wallet_password
        # TLS/DN matching is never disabled. Wallet and password stay in memory/temp only.
        with oracledb.connect(**kwargs) as connection:
            yield connection


def extract(connection, owner: str, tables: list[str], include_views: bool = False) -> dict:
    if not owner or not tables or len(tables) != len(set(tables)):
        raise ToolError("スキーマと重複のない対象テーブル一覧を明示してください。スキーマ全体は取得しません。")
    with connection.cursor() as cursor:
        cursor.execute("set transaction read only")
        try:
            cursor.execute("select sys_context('USERENV','CURRENT_SCHEMA'), sys_context('USERENV','DB_NAME') from dual")
            current_schema, database = cursor.fetchone()
            cursor.execute(TABLES_SQL, owner=owner)
            available = {r[1]: {"comment": r[2], "object_type": "TABLE"} for r in cursor}
            if include_views:
                cursor.execute(VIEWS_SQL, owner=owner)
                available.update({r[1]: {"comment": r[2], "object_type": "VIEW"} for r in cursor})
            missing = set(tables) - set(available)
            if missing:
                raise ToolError(f"表が存在しないか、読取り権限がありません（大文字と小文字を区別）: {sorted(missing)}")
            output = []
            for table_name in sorted(tables):
                cursor.execute(COLUMNS_SQL, owner=owner, table_name=table_name)
                columns = []
                for name, typ, byte_len, char_len, char_used, precision, scale, nullable, comment, ordinal in cursor:
                    length = char_len if char_used in ("C", "B") and typ in ("CHAR", "NCHAR", "VARCHAR2", "NVARCHAR2") else byte_len if typ == "RAW" else 0
                    columns.append(dict(name=name, data_type=typ, length=length or 0, byte_length=byte_len,
                                        precision=precision, scale=scale, nullable=nullable == "Y", comment=comment, ordinal=ordinal))
                cursor.execute(KEYS_SQL, owner=owner, table_name=table_name)
                key_rows=[]
                for record in cursor:
                    name,typ,column,position,r_owner,r_table,r_column,status,validated=record[:9]
                    key_rows.append(dict(name=name,type=typ,column=column,position=position,
                        target_owner=r_owner,target_table=r_table,target_column=r_column,
                        status=status,validated=validated,rely=record[9] if len(record)>9 else None))
                output.append(dict(owner=owner,name=table_name,**available[table_name],columns=columns,
                                   **key_metadata(key_rows)))
            return validate_metadata(dict(format_version=1, source="adb_dictionary_read_only", database=database,
                session_schema=current_schema, captured_at=datetime.now(timezone.utc).isoformat(), tables=output))
        finally:
            connection.rollback()


def extract_configured(db_config: dict, secrets: dict | None = None) -> dict:
    """Explicit transport selection; never downgrade or retry failed credentials."""
    transport = db_config.get("transport", "oracle")
    if transport == "ords":
        from .ords import extract_ords
        return extract_ords(db_config, secrets)
    if transport != "oracle":
        raise ToolError("db.transportはoracleまたはordsで指定してください。")
    with connect(db_config, secrets) as connection:
        return extract(connection, db_config["schema"], db_config["tables"], db_config.get("include_views", False))
