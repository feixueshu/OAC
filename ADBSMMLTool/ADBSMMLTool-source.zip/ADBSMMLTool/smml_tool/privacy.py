"""Fail-closed GitHub visibility check; no customer payload is sent to this API."""
from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from .core import ToolError


def verify_private_repository(origin: str, token: str | None = None) -> dict:
    if origin.startswith('file://'):
        return {'visibility': 'local_test_remote', 'verified': True}
    if origin.startswith('git@github.com:'):
        name = origin[len('git@github.com:'):]
    else:
        parts = urlsplit(origin)
        if parts.scheme != 'https' or parts.hostname != 'github.com' or parts.username or parts.password:
            raise ToolError('検証済みのGitHub非公開リポジトリのみ使用できます。未検証のリモートにはプッシュしません。')
        name = parts.path.lstrip('/')
    name = name.removesuffix('.git')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', name):
        raise ToolError('GitHubリポジトリURLの形式が不正です。')
    secret = token or os.environ.get('GITHUB_TOKEN')
    if not secret:
        raise ToolError('プッシュ前に非公開リポジトリを実際に検証する必要があります。本機でGitHub Tokenを入力するかGITHUB_TOKENを設定してください。Tokenは保存しません。')
    request = urllib.request.Request('https://api.github.com/repos/' + name, headers={
        'Authorization': 'Bearer ' + secret, 'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'adb-smml-private-only'})
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            repository = json.load(response)
    except urllib.error.HTTPError as error:
        raise ToolError(f'リポジトリが非公開であることを検証できません：GitHub HTTP {error.code}。プッシュを禁止します。') from None
    except (OSError, ValueError):
        raise ToolError('非公開状態を検証できません。ネットワークまたは応答が不正なためプッシュを禁止します。') from None
    if repository.get('full_name', '').casefold() != name.casefold() or repository.get('private') is not True or repository.get('visibility', 'private') != 'private':
        raise ToolError('PRIVATE_REPOSITORY_REQUIRED：同期先は非公開リポジトリではありません。お客様の定義情報はプッシュしません。')
    return {'repository': repository['full_name'], 'visibility': 'private', 'verified': True}
