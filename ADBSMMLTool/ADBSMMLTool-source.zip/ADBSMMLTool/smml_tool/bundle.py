from __future__ import annotations

import hashlib
import os
import tempfile
import zipfile
from pathlib import Path

from .core import ToolError, digest, read_json, write_json
from .generator import build_model, changes
from .workbook import export_workbook, read_review


def deployment_guide(model: dict, oac_url: str) -> str:
    if model['config']['strategy']=='foreign_key_star':
        simple=model['config'].get('constraint_policy')=='declared' and not model['config'].get('measures')
        measure_note='小数NUMBERを自動でメジャーにし、すべてのメジャーをSUMで生成します。キー列は属性です。集計規則の追加設定は不要です。' if simple else '小数NUMBERは既定でSUMメジャーです。単価・率・単位原価はmeasuresでAVG等へ上書きします。キー列は属性です。'
        value_check='SUM' if simple else 'SUM/AVG'
        layout_note='単一Subject Areaに全表のフォルダーを配置し、1つのBusiness Model内で共通ディメンションを共有します。ファクト同士の直接結合は追加しません。異なる粒度のメジャーとディメンションの組合せはOACの実クエリーで検証してください。' if model['config'].get('subject_area_layout')=='single' else '物理層はDB定義に基づくFK結合を持ちます。各表のSubject Areaにはその表のメジャーと祖先ディメンション属性を配置します。異なる粒度のメジャーを混在させて重複集計しない設計です。'
        return f"""# FK関連モデルのOAC反映手順

このモデルは未デプロイです。ローカルJSON検証をOACの整合性チェックと混同しないでください。

- OAC接続参照: {model['config']['oac_connection']}
- 物理FK: {model['stats']['physical_foreign_keys']}
- 論理FK結合: {model['stats']['logical_foreign_key_joins']} （複数Business Modelへの複製を含む）
- 元DB列のメジャー: {model['stats']['measure_columns']}
- OAC: {oac_url}

1. relationships.json と measure-classification.json を確認します。DBのRELY/DISABLED制約は実データの整合性を強制しません。
2. {layout_note}
3. {measure_note}
4. TRUEは論理/表示項目のみを除外します。結合キーを除外した場合は、その論理結合を切り離して警告します。物理列・物理FK・DBデータは削除しません。
5. 専用の非公開Gitへ差分確認後に明示的にPushします。初回はOACでClone、更新時はPullします。
6. OACで通常の整合性チェックとAdvanced Checkを実行します。実クエリーで件数と{value_check}の値を照合します。
7. 公開先と復旧手順を確認して手動Deployします。ツールはPull/Deployを自動実行しません。
"""
    return f"""# OAC反映とデプロイの手順

**生成時点では、このバージョンのOAC検証とデプロイは未実施です。**

- 定義の取得元: `{model['metadata'].get('source', 'unknown')}`
- OAC: {oac_url or '(OAC URLを設定してください)'}
- モデル生成方式: `{model['config']['strategy']}`

## 初回設定
1. OACに登録済みのADB接続を確認し、Semantic Modelerから使用可能にします。
2. `model.oac_connection`を実際の接続参照に合わせます。別環境の既定値のまま公開しないでください。
3. `model/`配下の3層SMMLを専用の非公開Gitリポジトリへ同期します。
4. OACで対象リポジトリとブランチをクローンし、別の開発モデルとして検証します。

## 更新時の操作
1. `changes.json`で日本語名とTRUEによる除外の差分を確認します。
2. Git同期の差分を確認し、リポジトリとブランチを確認してからコミットとプッシュを実行します。
3. プッシュの完了はOACへの反映やデプロイの完了を意味しません。
4. OACのGitパネルで対象ブランチをプルし、競合があれば内容を確認して解決します。
5. 「警告を含む」整合性チェックを実行します。デプロイ前には詳細チェック（Advanced Check）も行い、エラーを解決します。ローカルのJSON検証だけで公開しないでください。
6. 公開先、既存モデルへの影響、復旧手順を確認し、権限を持つ担当者がデプロイします。
7. デプロイ後、分析で名前、除外項目、件数を確認し、ADBの検証SQLと比較します。

## 安全上の注意
- Wallet、パスワード、Token、Excel、metadata.jsonはモデル用Gitに送信しません。
- TRUEは論理・表示項目だけを除外します。物理列とデータ行は削除せず、DDLやDMLも実行しません。
- 一つの物理表を属性表と集計表の2投影で表現します。異なる業務表間のJoinは自動推測しません。
- 各表の行数は自動生成したSUM(1)で表します。通常列の集計は明示したmeasuresのみを使用します。
- 全DB列をTRUEにした表は論理・表示オブジェクトを除外し、物理表を保持します。
- 名前変更と項目除外は既存分析に影響します。公開前に退避と回帰確認を行ってください。
- Git Push、OAC Pull、整合性チェック、Deployは、それぞれ実行結果を確認する別の工程です。

## Oracle公式資料
- https://docs.oracle.com/en/cloud/paas/analytics-cloud/acmdg/using-git-repositories-semantic-model-development.html
- https://docs.oracle.com/en/cloud/paas/analytics-cloud/acmdg/check-consistency-semantic-model.html
"""



def save_bundle(model: dict, output: str | Path, *, oac_url: str = "", previous: dict | None = None,
                with_excel: bool = True, preview: bool = False) -> dict:
    target = Path(output).expanduser().resolve()
    if target.exists():
        raise ToolError(f"出力先は既に存在します。新しいディレクトリを指定してください: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".smml-build-", dir=target.parent) as temp:
        stage = Path(temp) / "bundle"
        stage.mkdir()
        for path, doc in model["files"].items():
            write_json(stage / "model" / path, doc)
        write_json(stage / "metadata.json", model["metadata"])
        write_json(stage / "model-config.json", model["config"])
        write_json(stage / "review-state.json", model["review"])
        if "relationships" in model:
            write_json(stage/"relationships.json",model["relationships"])
            write_json(stage/"measure-classification.json",model["measure_classification"])
        write_json(stage / "validation.json", dict(model["validation"], warnings=model["warnings"], stats=model["stats"]))
        if previous is not None:
            write_json(stage / "changes.json", changes(previous, model))
        (stage / "DEPLOYMENT.md").write_text(deployment_guide(model, oac_url), encoding="utf-8")
        backend = export_workbook(model, stage / "review.xlsx", preview=preview) if with_excel else "not_exported"
        # Archive contains ONLY OAC SMML layers, not inputs, secrets, or workbook data.
        with zipfile.ZipFile(stage / "model.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(model["files"]):
                info = zipfile.ZipInfo(path, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, (stage / "model" / path).read_bytes())
        protected = [p for p in stage.rglob('*') if p.is_file() and p.suffix not in {'.xlsx', '.png'}]
        hashes = {p.relative_to(stage).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
        manifest = dict(format_version=1, model_sha256=digest(model["files"]), snapshot_sha256=digest(model["metadata"]),
                        stats=model["stats"], workbook_backend=backend, hashes=hashes,
                        oac_consistency_check="NOT_RUN", oac_deployed=False)
        write_json(stage / "manifest.json", manifest)
        os.replace(stage, target)
    return dict(output=str(target), **model["stats"], workbook_backend=backend, oac_deployed=False)


def load_bundle(path: str | Path) -> dict:
    root = Path(path).resolve()
    manifest = read_json(root / "manifest.json")
    for relative, expected in manifest["hashes"].items():
        candidate = root / relative
        if Path(relative).is_absolute() or '..' in Path(relative).parts or candidate.is_symlink() or not candidate.resolve().is_relative_to(root):
            raise ToolError("Manifestに不正なパスがあります。")
        if not candidate.is_file() or hashlib.sha256(candidate.read_bytes()).hexdigest() != expected:
            raise ToolError(f"元モデルのファイルが変更されています: {relative}")
    model = build_model(read_json(root / "metadata.json"), read_json(root / "model-config.json"), read_json(root / "review-state.json"))
    actual_paths = {p.relative_to(root / 'model').as_posix() for p in (root/'model').rglob('*') if p.is_file()}
    if actual_paths != set(model["files"]) or digest(model["files"]) != manifest["model_sha256"]:
        raise ToolError("元モデルの構成がManifestと一致しません。")
    for relative, doc in model["files"].items():
        candidate = root/'model'/relative
        if candidate.is_symlink() or not candidate.resolve().is_relative_to(root/'model') or read_json(candidate) != doc:
            raise ToolError(f"元SMMLファイルが改変されています: {relative}")
    return model


def apply_workbook(baseline: str | Path, workbook: str | Path, output: str | Path,
                   *, oac_url: str = "", with_excel: bool = True, preview: bool = False) -> dict:
    old = load_bundle(baseline)
    rows = read_review(workbook, old)
    new = build_model(old["metadata"], old["config"], rows)
    return save_bundle(new, output, oac_url=oac_url, previous=old, with_excel=with_excel, preview=preview)
