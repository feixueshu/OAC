from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any


class ToolError(ValueError):
    """An actionable, safe-to-display validation error."""


HEADERS = ["カテゴリ別名", "オブジェクト別名", "テーブル名", "カラム名", "アイテム別名", "属性", "サイズ", "削除フラグ"]
FORMATS = {"CHAR": "CHAR", "NCHAR": "CHAR", "VARCHAR": "VARCHAR", "VARCHAR2": "VARCHAR",
           "NVARCHAR2": "VARCHAR", "NUMBER": "NUMERIC", "DECIMAL": "NUMERIC", "NUMERIC": "NUMERIC",
           "INTEGER": "INT", "INT": "INT", "SMALLINT": "SMALLINT", "FLOAT": "FLOAT",
           "BINARY_FLOAT": "FLOAT", "BINARY_DOUBLE": "DOUBLE", "DATE": "DATETIME",
           "TIMESTAMP": "TIMESTAMP", "RAW": "VARBINARY", "BOOLEAN": "BOOLEAN"}
AGGREGATIONS = {"SUM", "AVG", "MIN", "MAX", "COUNT", "COUNT_DISTINCT"}
NUMERIC_TYPES = {"NUMERIC", "INT", "SMALLINT", "FLOAT", "DOUBLE"}


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def read_json(path: str | Path) -> dict:
    with Path(path).open(encoding="utf-8") as file:
        return json.load(file)


def write_json(path: str | Path, value: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def datatype(name: str) -> str:
    # TIMESTAMP WITH TIME ZONE needs an explicit conversion, never silently discard its zone.
    key = re.sub(r"\(\d+\)", "", name.upper()).strip()
    if key not in FORMATS:
        raise ToolError(f"未対応の Oracle 型: {name}。変換用 VIEW を明示的に用意してください。")
    return FORMATS[key]


def ref(kind: str, *names: str) -> str:
    def escape(name: str) -> str:
        return name.replace("\\", "\\\\").replace(".", "\\.")
    return kind + ":" + ".".join(escape(n) for n in names)


def filename(name: str) -> str:
    # Oracle replaces '/' on Unix; use the portable Windows superset, detect collisions separately.
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).rstrip(" .")
    if value in {"", ".", ".."}:
        raise ToolError(f"安全なファイル名にできません: {name!r}")
    if re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", value):
        value = "_" + value
    return value


def check_name(name: Any) -> str:
    if not isinstance(name, str) or not name or name != name.strip() or len(name) > 128:
        raise ToolError(f"名前は前後空白のない1〜128文字で指定してください: {name!r}")
    if re.search(r"[?*'\x00-\x1f]", name) or name.startswith(("=", "+", "-", "@")):
        raise ToolError(f"SMML名に使用できない文字、または数式のような先頭文字があります: {name!r}")
    return name


def comment_name(comment: str | None, fallback: str) -> str:
    value = re.sub(r"[?*'\x00-\x1f]", "_", (comment or "").strip()) or fallback
    if value.startswith(("=", "+", "-", "@")):
        value = "_" + value
    return check_name(value[:128])


def unique_names(pairs: list[tuple[str, str]]) -> dict[str, str]:
    used: set[str] = set()
    result = {}
    for key, preferred in pairs:
        name = preferred
        count = 0
        while name.casefold() in used:
            count += 1
            suffix = f"（{key}）" if count == 1 else f"（{key}_{count}）"
            name = preferred[:128-len(suffix)] + suffix
        check_name(name)
        used.add(name.casefold())
        result[key] = name
    return result


def table_id(table: dict) -> str:
    return table["owner"] + "." + table["name"]


def item_id(table: dict, column: dict) -> str:
    # Array identity avoids ambiguous dots in quoted Oracle identifiers.
    return canonical([table["owner"], table["name"], column["name"]])


def validate_metadata(source: dict) -> dict:
    data = copy.deepcopy(source)
    if data.get("format_version") != 1 or not isinstance(data.get("tables"), list) or not data["tables"]:
        raise ToolError("metadata.json は format_version=1 と空でない tables が必要です。")
    seen = set()
    for table in data["tables"]:
        for part in (table["owner"], table["name"]):
            if not isinstance(part, str) or not part or len(part) > 128 or re.search(r"[?*\x00-\x1f]", part) or part.startswith(("=", "+", "-", "@")):
                raise ToolError(f"未対応の物理オブジェクト名: {part!r}")
        ident = table_id(table)
        if ident in seen:
            raise ToolError(f"重複または曖昧なテーブル識別子: {ident}")
        seen.add(ident)
        if not table.get("columns"):
            raise ToolError(f"列がありません: {ident}")
        names = set()
        for col in table["columns"]:
            name = col["name"]
            if not isinstance(name, str) or not name or len(name) > 128 or re.search(r"[?*\x00-\x1f]", name) or name.startswith(("=", "+", "-", "@")):
                raise ToolError(f"未対応の物理カラム名: {name!r}")
            if name in names:
                raise ToolError(f"重複カラム: {ident}.{name}")
            names.add(name)
            datatype(col["data_type"])
            length = col.get("length", 0) or 0
            if not isinstance(length, int) or not 0 <= length <= 2147483647:
                raise ToolError(f"不正な length: {ident}.{name}")
            col.setdefault("length", length)
            col.setdefault("nullable", True)
        if not set(table.get("primary_key", [])).issubset(names):
            raise ToolError(f"存在しない主キーカラム: {ident}")
    # Stable ordering is independent of dictionary fetch order / workbook row order.
    data["tables"].sort(key=lambda t: (t["owner"], t["name"]))
    return data


def model_config(config: dict) -> dict:
    result = {"database_name": "ADB", "connection_pool": "ADB Connection Pool",
              "oac_connection": "", "business_model_prefix": "ADB",
              "subject_area_prefix": "ADB", "strategy": "single_table",
              "row_count_name": "行数（自動生成）", "measures": {}}
    new_options={"auto_decimal_measures","constraint_policy","subject_area_layout"}
    unknown = set(config) - set(result) - new_options
    if unknown:
        raise ToolError(f"未知のmodel設定: {sorted(unknown)}")
    result.update(config)
    for key in ("database_name", "connection_pool", "business_model_prefix", "subject_area_prefix", "row_count_name"):
        check_name(result[key])
    if result["strategy"] not in {"single_table", "single_table_star", "foreign_key_star"}:
        raise ToolError("strategyはsingle_table、single_table_star、foreign_key_starのいずれかです。")
    if result["strategy"]=="foreign_key_star":
        result.setdefault("auto_decimal_measures",True)
        result.setdefault("constraint_policy","validated_only")
        if type(result["auto_decimal_measures"]) is not bool or result["constraint_policy"] not in {"validated_only","validated_or_rely","declared"}:
            raise ToolError("自動メジャー設定または制約ポリシーが不正です。")
        if "subject_area_layout" in result and result["subject_area_layout"] not in {"single","per_table"}:
            raise ToolError("subject_area_layoutはsingleまたはper_tableです。")
    elif set(config)&new_options:
        raise ToolError("関連モデルのオプションはforeign_key_starでのみ使用できます。")
    if not isinstance(result["oac_connection"], str) or not result["oac_connection"].strip():
        raise ToolError("OACに登録された接続参照が必要です。例: 'system'.'ADB_CONNECTION'")
    for table, measures in result["measures"].items():
        if not isinstance(measures, dict) or any(v not in AGGREGATIONS for v in measures.values()):
            raise ToolError(f"集計規則が不正です: {table}")
    return result



def normalize_delete_flag(value: Any, *, row: int | None = None) -> str:
    """Canonical public TRUE/FALSE; accept the historical TRUTH alias on input."""
    if type(value) is bool:return 'TRUE' if value else 'FALSE'
    if isinstance(value,str):
        text=value.strip().upper()
        if text in {'TRUE','TRUTH'}:return 'TRUE'
        if text=='FALSE':return 'FALSE'
    where=f'Excel {row}行: ' if row is not None else ''
    raise ToolError(where+'削除フラグはTRUE / FALSEを指定してください（空欄・数値は不可）。')


def initial_review(metadata: dict, config: dict) -> list[list]:
    rows = []
    table_aliases = unique_names([(table_id(t), t["name"] if config["strategy"]=="foreign_key_star" else comment_name(t.get("comment"), t["name"])) for t in metadata["tables"]])
    categories = unique_names([(table_id(t), comment_name(config["subject_area_prefix"] + " - " + table_aliases[table_id(t)], t["name"])) for t in metadata["tables"]])
    if config.get("subject_area_layout")=="single":
        categories={table_id(t):config["subject_area_prefix"] for t in metadata["tables"]}
    for table in metadata["tables"]:
        ident = table_id(table)
        cols = unique_names([(c["name"], comment_name(c.get("comment"), c["name"])) for c in table["columns"]])
        # Reserve the synthetic count name so it cannot collide with a source-column comment.
        if config["row_count_name"].casefold() in {v.casefold() for v in cols.values()}:
            raise ToolError(f"{ident}: DB列のCOMMENTが自動行数列名と重複。row_count_nameを変更してください。")
        for column in table["columns"]:
            rows.append([categories[ident], table_aliases[ident], ident, column["name"], cols[column["name"]],
                         (oracle_type(column) if config["strategy"]=="foreign_key_star" else column["data_type"]), column.get("length", 0) or 0, "FALSE"])
    return rows


def oracle_type(column: dict) -> str:
    kind=column['data_type']
    precision,scale=column.get('precision'),column.get('scale')
    if kind=='NUMBER' and precision is not None:
        return f"NUMBER({precision},{scale})" if scale is not None else f"NUMBER({precision})"
    return kind
