"""One subject area and one business model, with shared dimensions and native facts.
Reuse the existing FK/physical builder to preserve its validation and physical bytes.
No new database keys or fact-to-fact joins are inferred by consolidation.
"""
from __future__ import annotations
import copy
from .core import ToolError, check_name, digest, filename, ref, table_id
from .relationships import build_relationship_model
from .validation import validate_files


def build_shared_subject_model(metadata, config, rows):
    # Private per-root construction is only a validated intermediate representation.
    # Presentation objects and ancestor copies from it are NOT delivered.
    legacy=copy.deepcopy(config);legacy.pop('subject_area_layout',None)
    private=copy.deepcopy(rows)
    tables={table_id(t):t for t in metadata['tables']}
    categories={ident:f'_SMML_ROOT_{i}' for i,ident in enumerate(tables)}
    for row in private:row[0]=categories[row[2]]
    base=build_relationship_model(metadata,legacy,private)
    files={p:copy.deepcopy(d) for p,d in base['files'].items() if p.startswith('physical/')}
    live={ident:[r for r in rows if r[2]==ident and r[7]=='FALSE'] for ident in tables}
    live={ident:rs for ident,rs in live.items() if rs}
    warnings=[w for w in base['warnings'] if not w.startswith('FKに沿って表ごとに独立したSubject Area')]
    warnings.append('単一Subject Areaに全表のフォルダーを配置します。共通ディメンションを共有し、ファクト同士の直接結合は追加しません。異なる粒度や未関連項目の組合せはOACで別途検証してください。')
    if not live:
        return dict(base,config=config,review=rows,files=files,warnings=warnings,
                    validation=dict(validate_files(files),reference_integrity='passed'),
                    stats=dict(base['stats'],subject_areas=0,logical_foreign_key_joins=0))
    category=rows[0][0];bm=config['business_model_prefix'];check_name(bm)
    aliases={ident:rs[0][1] for ident,rs in live.items()}
    used={a.casefold() for a in aliases.values()};facts={}
    for ident,alias in aliases.items():
        name=alias[:117]+'（メジャー）'
        if name.casefold() in used:
            name=alias[:102]+'（FACT-'+digest(ident)[:8]+'）'
        counter=0
        while name.casefold() in used:
            counter+=1;name=alias[:98]+'（FACT-'+digest(ident+str(counter))[:8]+'）'
        check_name(name);used.add(name.casefold());facts[ident]=name
    usable=[]
    lookup={(r[2],r[3]):r for r in rows}
    for e in base['relationships']:
        if e['source'] in live and e['target'] in live and all(lookup[e['source'],c][7]=='FALSE' for c in e['columns']) and all(lookup[e['target'],c][7]=='FALSE' for c in e['target_columns']):
            usable.append(e)
    # A referenced table is a shared dimension role. Its outgoing FKs (e.g.
    # CUSTOMERS->COUNTRIES) are placed once on that dimension, not also on its
    # own measure projection: that would create two navigation paths.
    shared_dimensions={e['target'] for e in usable}
    def add(path,kind,obj):
        if path.casefold() in {p.casefold() for p in files}:raise ToolError('SMMLファイル名が衝突しています: '+path)
        files[path]={kind:obj}
    add(f'logical/{filename(bm)}.json','businessModel',dict(name=bm,disable=False))
    for ident in live:
        oldarea=base['files'][f'presentation/{categories[ident]}.json']['subjectArea']
        oldbmref=oldarea['sourceBusinessModel']
        oldbm=next(d['businessModel']['name'] for d in base['files'].values() if 'businessModel' in d and ref('businessModel',d['businessModel']['name'])==oldbmref)
        prefix=f'logical/{filename(oldbm)}/'
        oldfact=next(d['logicalTable'] for p,d in base['files'].items() if p.startswith(prefix) and 'logicalTable' in d and d['logicalTable']['type']=='FACT')
        oldalias=oldfact['name']
        def rewrite(v):
            if isinstance(v,dict):return {k:rewrite(x) for k,x in v.items()}
            if isinstance(v,list):return [rewrite(x) for x in v]
            if isinstance(v,str):
                for kind in ('logicalTable','logicalColumn'):
                    old=ref(kind,oldbm,oldalias)
                    if v==old or v.startswith(old+'.'):return ref(kind,bm,facts[ident])+v[len(old):]
                    old=ref(kind,oldbm)+'.'
                    if v.startswith(old):return ref(kind,bm)+'.'+v[len(old):]
            return v
        dim=rewrite(base['files'][prefix+filename(aliases[ident])+'.json']['logicalTable'])
        dim.pop('joins',None)
        fact=rewrite(oldfact);fact['name']=facts[ident]
        fact['joins']=[dict(rightTable=ref('logicalTable',bm,aliases[ident]),joinType='INNER',cardinality='MANY_TO_ONE')]
        for e in usable:
            if e['source']!=ident:continue
            join=dict(rightTable=ref('logicalTable',bm,aliases[e['target']]),joinType=e['join_type'],cardinality='MANY_TO_ONE')
            if ident in shared_dimensions:dim.setdefault('joins',[]).append(join)
            else:fact['joins'].append(join)
        add(f'logical/{filename(bm)}/{filename(aliases[ident])}.json','logicalTable',dim)
        add(f'logical/{filename(bm)}/{filename(facts[ident])}.json','logicalTable',fact)
        oldpresentation=base['files'][f'presentation/{categories[ident]}/{filename(aliases[ident])}.json']['presentationTable']
        add(f'presentation/{filename(category)}/{filename(aliases[ident])}.json','presentationTable',rewrite(oldpresentation))
    # Prefer the main sales fact for attribute-only navigation in this dataset.
    # Never use this as evidence that arbitrary cross-fact combinations are valid.
    implicit=next((i for i in live if tables[i]['name']=='SALES'),next(iter(live)))
    add(f'presentation/{filename(category)}.json','subjectArea',dict(name=category,sourceBusinessModel=ref('businessModel',bm),implicitFactColumn=ref('logicalColumn',bm,facts[implicit],config['row_count_name'])))
    targets=set()
    for p,d in files.items():
        if 'businessModel' in d:targets.add(ref('businessModel',d['businessModel']['name']))
        elif 'logicalTable' in d:
            t=d['logicalTable'];targets.add(ref('logicalTable',bm,t['name']))
            targets.update(ref('logicalColumn',bm,t['name'],c['name']) for c in t['logicalColumns'])
        elif 'physicalTable' in d:
            t=d['physicalTable'];ident=next(i for i in tables if p==f'physical/{filename(config["database_name"])}/{filename(tables[i]["owner"])}/{filename(tables[i]["name"])}.json')
            tab=tables[ident];targets.add(ref('physicalTable',config['database_name'],tab['owner'],tab['name']))
            targets.update(ref('physicalColumn',config['database_name'],tab['owner'],tab['name'],c['name']) for c in t['physicalColumns'])
    def check(v,key=None):
        if isinstance(v,dict):
            for k,x in v.items():check(x,k)
        elif isinstance(v,list):
            for x in v:check(x,key)
        elif isinstance(v,str) and key in {'rightTable','drivingTable','expressionObjects','tables','sourceBusinessModel','sourceLogicalColumn','implicitFactColumn'} and v not in targets:
            raise ToolError('SMML参照先がありません: '+v)
    check(files)
    return dict(base,config=config,review=rows,files=files,warnings=warnings,
                validation=dict(validate_files(files),reference_integrity='passed'),
                stats=dict(base['stats'],subject_areas=1,logical_foreign_key_joins=len(usable)))
