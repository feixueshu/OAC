from __future__ import annotations

import copy
import json
from importlib import resources
from pathlib import Path
from jsonschema import Draft4Validator
from .core import ToolError, read_json

SCHEMAS = Path(__file__).resolve().parents[1] / "schemas"
KINDS = {"database": "database", "schema": "schema", "physicalTable": "physical-table",
         "businessModel": "business-model", "logicalTable": "logical-table",
         "subjectArea": "subject-area", "presentationTable": "presentation-table"}


def read_schema(name: str) -> dict:
    bundled = resources.files("smml_tool").joinpath("data").joinpath("schemas").joinpath(name)
    return json.loads(bundled.read_text(encoding="utf-8")) if bundled.is_file() else read_json(SCHEMAS / name)


def schema_for(kind: str) -> dict:
    schema = read_schema(KINDS[kind] + ".json")
    common = read_schema("common.json")["definitions"]
    # Published pages refer to common/common_schemas and omit PhysicalColumn.DataType.
    # Bundle common definitions and normalize these *documented* references locally.
    schema = copy.deepcopy(schema)
    schema["definitions"].update({k: v for k, v in common.items() if k not in schema["definitions"]})
    def normalize(node):
        if isinstance(node, dict):
            for key, value in list(node.items()):
                if key == "$ref" and (value.startswith("common_schemas#") or value.startswith("common#")):
                    node[key] = value[value.index("#"):]
                else:
                    normalize(value)
        elif isinstance(node, list):
            for value in node:
                normalize(value)
    normalize(schema)
    return schema


def validate_files(files: dict[str, dict]) -> dict:
    errors = []
    validators = {kind: Draft4Validator(schema_for(kind)) for kind in KINDS}
    for path, document in files.items():
        if len(document) != 1 or next(iter(document)) not in validators:
            errors.append(f"{path}: unknown SMML object wrapper")
            continue
        kind = next(iter(document))
        try:
            for error in validators[kind].iter_errors(document[kind]):
                errors.append(f"{path}: {'/'.join(map(str, error.path))}: {error.message}")
        except Exception as error:
            raise ToolError(f"Schema参照の解決失敗: {kind}: {error}") from error
    if errors:
        raise ToolError("SMML JSON Schema validation failed:\n" + "\n".join(errors[:20]))
    return {"json_schema": "passed", "object_count": len(files),
            "oac_consistency_check": "NOT_RUN", "oac_deployed": False,
            "note": "JSONスキーマ検証はOAC一貫性チェック・クエリ実行の代替ではありません。"}
