from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .adb import extract_configured
from .bundle import apply_workbook, load_bundle, save_bundle
from .core import ToolError, read_json, write_json
from .ui_config import validate_public_config, customer_generation_config, require_customer_model
from .generator import build_model
from .git_sync import apply_sync, sync_plan


def load_config(path: str | Path) -> dict:
    source = Path(path).resolve()
    config = read_json(source)
    validate_public_config(config)
    db = config.get("db", {})
    forbidden = set(db) & {"password", "wallet_password", "token", "user", "username"}
    if forbidden or "github_token" in config:
        raise ToolError("db設定に認証情報は保存できません。ユーザー名の既定値にはui.adb_username、パスワードには環境変数または画面入力を使用してください。")
    if db.get("wallet"):
        wallet = Path(db["wallet"]).expanduser()
        db["wallet"] = str(wallet if wallet.is_absolute() else (source.parent / wallet).resolve())
    return config


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="ADB定義からSMMLを生成 Excel確認と安全なGit同期")
    commands = p.add_subparsers(dest="command", required=True)
    discover = commands.add_parser("extract", help="指定したADB表の定義を読取り専用で取得")
    discover.add_argument("--config", required=True)
    discover.add_argument("--out", required=True)
    generate = commands.add_parser("generate", help="SMMLを生成してExcelを出力 GitとOACへの書込みなし")
    generate.add_argument("--config", required=True)
    generate.add_argument("--metadata", help="オフライン定義スナップショット 省略時はADBから取得")
    generate.add_argument("--out", required=True)
    generate.add_argument("--no-excel", action="store_true")
    generate.add_argument("--preview", action="store_true")
    update = commands.add_parser("apply", help="Excelを検証して別の更新版を生成 元モデルは上書きしません")
    update.add_argument("--baseline", required=True)
    update.add_argument("--excel", required=True)
    update.add_argument("--out", required=True)
    update.add_argument("--oac-url", default="")
    update.add_argument("--no-excel", action="store_true")
    update.add_argument("--preview", action="store_true")
    validate = commands.add_parser("validate", help="モデル内容と参照とファイルハッシュを再検証")
    validate.add_argument("bundle")
    sync = commands.add_parser("git-sync", help="既定は差分確認のみ 明示的な確認後にコミットとプッシュ")
    sync.add_argument("--bundle", required=True)
    sync.add_argument("--repo", required=True)
    sync.add_argument("--branch", required=True)
    sync.add_argument("--origin", required=True)
    sync.add_argument("--confirm", action="store_true")
    sync.add_argument("--push", action="store_true")
    sync.add_argument("--message", default="Update generated ADB semantic model")
    return p


def run(args) -> dict:
    if args.command in {"extract", "generate"}:
        config = customer_generation_config(load_config(args.config))
        if args.command == "generate" and args.metadata:
            metadata = read_json(args.metadata)
        else:
            metadata = extract_configured(config["db"])
        if args.command == "extract":
            if Path(args.out).exists():
                raise ToolError("定義の出力先は既に存在します。上書きしません。")
            write_json(args.out, metadata)
            return {"output": str(Path(args.out).resolve()), "tables": len(metadata["tables"]), "database_writes": 0}
        return save_bundle(build_model(metadata, config["model"]), args.out,
                           oac_url=config.get("oac", {}).get("url", ""), with_excel=not args.no_excel, preview=args.preview)
    if args.command == "apply":
        require_customer_model(load_bundle(args.baseline))
        return apply_workbook(args.baseline, args.excel, args.out, oac_url=args.oac_url,
                              with_excel=not args.no_excel, preview=args.preview)
    if args.command == "validate":
        model = load_bundle(args.bundle)
        return {"validation": model["validation"], "stats": model["stats"]}
    if args.command == "git-sync":
        if args.push and not args.confirm:
            raise ToolError("--pushには--confirmの明示指定が必要です。既定では差分確認のみで、外部への書込みはありません。")
        if args.confirm:
            return apply_sync(args.bundle, args.repo, args.branch, args.origin, confirmed=True, push=args.push, message=args.message)
        return sync_plan(args.bundle, args.repo, args.branch, args.origin)
    raise ToolError("不明なコマンドです。")


def main() -> int:
    args = parser().parse_args()
    try:
        result = run(args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (ToolError, OSError, ValueError, KeyError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        return 2
    except Exception as error:
        # Driver exceptions can contain context; avoid printing secrets or descriptors by default.
        print(f"ERROR: {type(error).__name__}。接続と設定を確認してください。同期とデプロイは続行していません。", file=sys.stderr)
        return 3
