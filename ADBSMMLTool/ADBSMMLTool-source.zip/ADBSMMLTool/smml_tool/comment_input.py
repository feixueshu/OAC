"""Read a three-column table/column/comment workbook; never writes to a database."""
from __future__ import annotations
from contextlib import closing
import hashlib
import io
from pathlib import Path
import re
import zipfile
from openpyxl import load_workbook
from .core import ToolError

IDENTIFIER = re.compile(r'[A-Z][A-Z0-9_$#]{0,127}\Z')
HEADERS = {('TABLE_NAME','COLUMN_NAME','COMMENT'),('TABLE_NAME','COLUMN_NAME','COMMENTS'),
           ('テーブル名','カラム名','コメント'),('表名','字段名','日文名')}


def read_comment_input(path: str | Path) -> dict:
    """Ignore entirely blank rows; require explicit, unique, formula-free mappings."""
    source=Path(path).expanduser().resolve()
    try:
        raw=source.read_bytes()
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            infos=archive.infolist()
            if len(infos)>1000 or sum(i.file_size for i in infos)>128*1024*1024:
                raise ToolError('入力Excelの展開サイズが大きすぎます。')
        entries=[];seen=set();tables=[]
        with closing(load_workbook(io.BytesIO(raw),read_only=True,data_only=False,keep_links=False)) as book:
            for sheet in book:
                if (sheet.max_row or 0)>200_001 or (sheet.max_column or 0)>32:
                    raise ToolError('入力Excelが大きすぎます。')
                first_nonempty=True
                for number,row in enumerate(sheet.iter_rows(),1):
                    values=[c.value for c in row]
                    if all(v is None for v in values):continue
                    if any(c.data_type=='f' for c in row) or len(values)<3 or any(v is not None for v in values[3:]):
                        raise ToolError(f'{sheet.title} {number}行：数式を使わず、表名・列名・コメントの3列で指定してください。')
                    values=values[:3]
                    if first_nonempty and tuple(values) in HEADERS:
                        first_nonempty=False;continue
                    first_nonempty=False
                    table,column,comment=values
                    if any(not isinstance(v,str) or not IDENTIFIER.fullmatch(v) for v in [table,column]):
                        raise ToolError(f'{sheet.title} {number}行：表名と列名は大文字のOracle識別子で指定してください。')
                    if not isinstance(comment,str) or not comment.strip() or comment!=comment.strip():
                        raise ToolError(f'{sheet.title} {number}行：前後空白のない日本語コメントが必要です。')
                    if '\x00' in comment or len(comment.encode('utf-8'))>4000:
                        raise ToolError(f'{sheet.title} {number}行：コメントの文字またはサイズが不正です。')
                    key=(table,column)
                    if key in seen:raise ToolError(f'{sheet.title} {number}行：表と列が重複しています。')
                    seen.add(key)
                    if table not in tables:tables.append(table)
                    entries.append(dict(sheet=sheet.title,row=number,table=table,column=column,comment=comment))
        if not entries:raise ToolError('入力Excelに表・列・コメントの定義がありません。')
        return dict(format_version=1,source_file=source.name,source_sha256=hashlib.sha256(raw).hexdigest(),tables=tables,entries=entries)
    except (OSError,zipfile.BadZipFile,ValueError) as error:
        if isinstance(error,ToolError):raise
        raise ToolError('入力Excelを読み込めません。xlsx形式とファイルを確認してください。') from error


def model_settings_for_input(config: dict, mapping: dict, schema: str) -> dict:
    """Make editable defaults from an explicit workbook scope; no network or DDL."""
    import copy
    from .ui_config import validate_public_config
    if not isinstance(schema,str) or not IDENTIFIER.fullmatch(schema):
        raise ToolError('スキーマ名が不正です。')
    validate_public_config(config)
    if not mapping.get('tables') or any(not isinstance(t,str) or not IDENTIFIER.fullmatch(t) for t in mapping['tables']) or len(mapping['tables'])!=len(set(mapping['tables'])):
        raise ToolError('重複のない対象テーブル一覧が必要です。')
    result=copy.deepcopy(config)
    result['db'].update(schema=schema,tables=list(mapping['tables']),include_views=False)
    if result['db'].get('transport')=='ords':result['db']['wallet']=None
    result['model'].update(strategy='foreign_key_star' if result['model'].get('strategy')=='foreign_key_star' else 'single_table_star',business_model_prefix=schema,subject_area_prefix=schema)
    result.setdefault('ui',{}).update(language='ja',data_source='live')
    # The old OAC editor URL is not a validation or deployment target for this new model.
    result.setdefault('oac',{})['workspace_url']=''
    validate_public_config(result)
    return result
