"""Japanese local review UI. No automatic Git push, OAC deploy, or database DML."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import sys
from uuid import uuid4

# A customer zipapp embeds this script and extracts it only into its private runtime.
ROOT=Path(os.environ.get('ADB_SMML_HOME',Path(__file__).resolve().parent)).resolve()
if (ROOT/'smml-tool.pyz').is_file():sys.path.insert(0,str(ROOT/'smml-tool.pyz'))
import streamlit as st
from smml_tool.adb import extract_configured
from smml_tool.bundle import load_bundle, save_bundle
from smml_tool.cli import load_config
from smml_tool.core import ToolError, read_json, digest
from smml_tool.generator import build_model, changes
from smml_tool.git_sync import apply_sync, sync_plan
from smml_tool.workbook import read_review
from smml_tool.ui_config import config_path, export_public_config, same_origin, customer_generation_config, require_customer_model

st.set_page_config(page_title='ADB SMML モデル生成ツール',page_icon='🧩',layout='wide')
st.title('ADB SMML モデル生成ツール')
st.caption('ADBのコメントから3層モデルを生成し、Excelで日本語名と公開対象列を確認します。データベースの行・列は変更しません。')
if 'session_id' not in st.session_state:st.session_state.session_id=uuid4().hex[:12]
WORK=ROOT/'outputs'/st.session_state.session_id
source=config_path(ROOT)
try:
    config=customer_generation_config(load_config(source))
except (ToolError,OSError,ValueError,KeyError) as error:
    st.error("設定ファイルを読み込めません。保存場所とJSON形式、認証情報を含まないことを確認してください。")
    st.caption(str(error))
    st.stop()
ui=config.get('ui',{})
local_git=read_json(ROOT/'github.local.json') if (ROOT/'github.local.json').is_file() else {}
github=config.get('github',{})
st.info('操作順序：① モデル生成 → ② Excel変更の反映 → ③ 非公開GitHubへ同期 → ④ OACでプルと整合性チェック。デプロイは別途確認して実施します。')
with st.expander('はじめに 操作の流れと注意事項'):
    st.markdown('''1. **モデル生成**：スキーマと対象テーブル・ビューを確認して生成します。既存の主外キーを反映し、小数NUMBERのメジャーはSUMで生成します。
2. **Excel変更**：確認用Excelを編集します。以前の出力も、表・列と定義が一致すれば使用できます。変更できる列は **A・B・E・H**。列を除外する場合、H列に **TRUE** を指定します。Excelの行は削除しません。
3. **GitHub同期**：差分と同期先を確認し、必要な場合のみコミットとプッシュを実行します。非公開リポジトリであることをプッシュ前に検証します。
4. **OAC反映**：対象モデルで **プル → origin/main → プル**、続いて **警告を含む** 整合性チェックを実施します。デプロイ前には **詳細チェック（Advanced Check）** も行います。GitHubへのプッシュだけではOACに反映されません。

データ行の確認はOACの **物理レイヤー → データベース → スキーマ → 対象表をダブルクリック → プレビュー** で行います。列名変更と除外の結果は論理レイヤーとプレゼンテーション・レイヤーで確認してください。

接続先を変更した場合は、ユーザー名・パスワード・OAC接続参照も確認してください。既存の分析に影響するため、デプロイ前に対象環境と復旧手順を確認します。''')

with st.sidebar:
    st.header('接続とモデルの設定')
    st.caption('お客様のADB接続情報に変更して利用できます。取得するのは表・列の定義とコメントのみで、ADBの表・列・データ行は変更しません。')
    st.caption('表とビューを同じ規則で処理します。DBに宣言された主外キーを反映し、存在しない関連は推測しません。小数NUMBERは自動でメジャーにし、集計はSUMで生成します。')
    owner=st.text_input('ADBスキーマ',config['db']['schema'],help='大文字と小文字を区別します。接続ユーザーと異なるスキーマも、権限があれば指定できます。')
    tables=st.text_area('対象テーブル一覧',', '.join(config['db']['tables']),help='カンマまたは改行で区切ります。ここに指定した表・ビューだけを取得します。')
    user=st.text_input('ADBユーザー名',os.environ.get(config['db'].get('user_env','ADB_USER')) or ui.get('adb_username','admin'))
    password=st.text_input('ADBパスワード',value=os.environ.get(config['db'].get('password_env','ADB_PASSWORD'),''),type='password',help='既定値は本機の環境変数からのみ取得します。設定ファイルや配布パッケージには保存しません。')
    wallet_password=''
    connection_name=st.text_input('OACデータ接続参照',config['model']['oac_connection'],help="OACからエクスポートしたSMMLのdatabase.connectionPools[].connectionを指定します。接続表示名から推測しないでください。名前変更後も内部参照は元の名前の場合があります。ADBの接続文字列ではありません。")
    connection_display=config.get('oac',{}).get('connection_display_name','')
    if connection_display and connection_name==config['model']['oac_connection']:
        st.caption(f'この設定のOAC接続表示名：{connection_display}。上の欄はSMML内部参照です。表示名と異なる場合があります。')
    database_name=st.text_input('物理データベース名',config['model']['database_name'],help='SMML物理レイヤー内の表示名です。ADBのサービス名や実データベース名を変更する設定ではありません。')
    subject_prefix=st.text_input('サブジェクト領域名',config['model']['subject_area_prefix'],help='全表をまとめる単一Subject Areaの名前です。Excelのカテゴリ別名も全行この名前になります。')
    st.caption('各欄は既定値を変更できます。パスワードはマスク表示され、設定のダウンロードには含まれません。')
    with st.expander('接続先と詳細設定'):
        transport=st.selectbox('ADBへの接続方式',['ords','oracle'],index=0 if config['db'].get('transport','oracle')=='ords' else 1,help='ords：既存HTTPSインターフェース。oracle：Walletとoracledbドライバーを使用。')
        ords_url=st.text_input('ADB HTTPSエンドポイント',config['db'].get('ords_url',''),help='別のADB環境を使う場合に変更します。形式：https://ホスト/ords/スキーマ別名/_/sql')
        expected_db=st.text_input('接続先DB名の照合値',config['db'].get('expected_database',''),help='接続先取り違えを防ぐためDB_NAMEと照合します。別環境では必ず変更してください。')
        dsn=st.text_area('ADB接続文字列 DSN',config['db'].get('dsn',''),help='oracle方式で使用します。')
        wallet=st.text_input('Wallet ZIPまたはフォルダー',config['db'].get('wallet','') or '')
        if transport=='oracle':wallet_password=st.text_input('Walletパスワード',type='password')
        oac_url=st.text_input('OAC URL',config.get('oac',{}).get('url',''))
        workspace_url=st.text_input('OACモデルのURL 任意',config.get('oac',{}).get('workspace_url',''))
    settings=copy.deepcopy(config)
    settings['db'].update(schema=owner,tables=[x.strip() for x in tables.replace(',', '\n').splitlines() if x.strip()],include_views=True,transport=transport,ords_url=ords_url,expected_database=expected_db,dsn=dsn,wallet=wallet or None)
    settings['model'].update(oac_connection=connection_name,database_name=database_name,subject_area_prefix=subject_prefix)
    settings['oac']={'url':oac_url,'workspace_url':workspace_url,'connection_display_name':connection_display if connection_name==config['model']['oac_connection'] else ''}
    st.caption('設定ファイル：'+source.name)
    try:
        public=export_public_config(settings,username=user,wallet=wallet)
        st.download_button('既定値を保存 パスワード除外',json.dumps(public,ensure_ascii=False,indent=2)+'\n','settings.json',mime='application/json',help='次回起動時の既定値として、ツールと同じフォルダーのsettings.jsonに保存します。環境変数ADB_SMML_CONFIGでも設定ファイルを指定できます。')
        settings_error=None
    except (ToolError,ValueError) as err:
        settings_error=err
        st.warning('接続と既定値の設定を確認してください。')


def error_message(error):
    if isinstance(error,(ToolError,FileNotFoundError,json.JSONDecodeError)):
        st.error(str(error))
    else:
        st.error(f'{type(error).__name__}：処理に失敗しました。接続と設定を確認してください。同期やデプロイは続行していません。')


def summary(path, *, show_relationship_details=True):
    model=load_bundle(path)
    for target,key,label in zip(st.columns(4),['physical_tables','active_source_columns','deleted_semantic_columns','subject_areas'],['物理表','保持する項目','除外する項目','サブジェクト領域']):target.metric(label,model['stats'][key])
    if model['metadata'].get('source')!='adb_dictionary_read_only':st.warning('オフライン検証用のモデルです。実環境へのプッシュには使用できません。')
    a,b=st.columns(2)
    if (Path(path)/'review.xlsx').exists():a.download_button('確認用Excelをダウンロード',(Path(path)/'review.xlsx').read_bytes(),'review.xlsx',mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',key=str(path)+'excel')
    b.download_button('SMML ZIPをダウンロード',(Path(path)/'model.zip').read_bytes(),'model.zip',mime='application/zip',key=str(path)+'zip')
    st.caption('モデル出力先：'+str(path))
    if show_relationship_details and 'relationships' in model:
        for col,key,label in zip(st.columns(2),['physical_foreign_keys','measure_columns'],['物理FK結合','DB列のメジャー']):col.metric(label,model['stats'][key])
        with st.expander('FKとメジャーの判定結果'):
            measure_labels={'table':'テーブル','column':'列','oracle_type':'Oracle型','rule':'集計','reason':'判定根拠'}
            reason_labels={'explicit':'明示設定','fixed_decimal_positive_scale':'小数桁付きNUMBER'}
            st.dataframe([{measure_labels[k]:reason_labels.get(v,v) if k=='reason' else v for k,v in row.items()} for row in model['measure_classification']],hide_index=True)
            relation_labels={'name':'制約名','source':'参照元','target':'参照先','columns':'外部キー列','target_columns':'参照先キー列','target_key':'参照先キー','join_type':'結合方式'}
            st.dataframe([{label:row[key] for key,label in relation_labels.items() if key in row} for row in model['relationships']],hide_index=True)
            st.caption('DBに宣言された関連を反映します。関連のない表・ビューに業務結合は追加しません。')


def show_changes(change):
    labels={'category':'カテゴリ別名','object_alias':'オブジェクト別名','item_alias':'アイテム別名','delete_flag':'削除フラグ'}
    rows=[{'テーブル':event['table'],'列':event['column'],'変更項目':labels.get(key,key),'変更前':value['before'],'変更後':value['after']} for event in change['items'] for key,value in event['changes'].items()]
    if rows:st.dataframe(rows,hide_index=True)


tab1,tab2,tab3,tab4=st.tabs(['1 モデル生成','2 Excel変更の反映','3 GitHub同期','4 OAC反映'])
with tab1:
    st.subheader('1 SMMLを生成してからExcelを出力')
    st.write('論理レイヤーとプレゼンテーション・レイヤーの日本語名にADBのCOMMENTを使用します。COMMENTがない項目は物理名を使用して警告します。')
    if st.button('3層SMMLと確認用Excelを生成',type='primary'):
        try:
            if settings_error:raise settings_error
            if not user.strip() or not password:raise ToolError('ADBユーザー名とパスワードを入力してください。パスワードの既定値には本機の環境変数を使用できます。')
            snapshot=extract_configured(settings['db'],{'user':user,'password':password,'wallet_password':wallet_password})
            destination=WORK/('initial-'+uuid4().hex[:8])
            with st.spinner('定義を取得し、SMMLの生成とExcelの出力を実行しています…'):
                save_bundle(build_model(snapshot,settings['model']),destination,oac_url=oac_url)
            st.session_state.baseline=str(destination);st.session_state.pop('updated',None)
            st.success('モデルとExcelを生成しました。GitHubやOACへの書込みは行っていません。')
        except Exception as err:error_message(err)
    existing=st.text_input('既存のモデルを読み込む manifest.jsonがあるフォルダー',placeholder='/absolute/path/to/bundle')
    if st.button('既存モデルを読み込む'):
        try:
            candidate=load_bundle(existing);require_customer_model(candidate);st.session_state.baseline=str(Path(existing).resolve());st.session_state.pop('updated',None)
            st.success('モデルの読込みとローカル検証が完了しました。')
        except Exception as err:error_message(err)
    if st.session_state.get('baseline'):summary(st.session_state.baseline)
with tab2:
    st.subheader('2 日本語名の変更と項目の除外')
    st.info('編集可能な列はA・B・E・Hです。削除フラグはTRUEで論理・表示項目から除外、FALSEで保持します。文字列・論理値のどちらも使用できます。Excelの行は削除しないでください。')
    st.caption('以前に出力したExcelも使用できます。表名・カラム名と定義を現在のモデルと照合します。')
    upload=st.file_uploader('変更した確認用Excelをアップロード',type=['xlsx'])
    if st.button('Excelを検証して更新版SMMLを生成',type='primary'):
        try:
            if not st.session_state.get('baseline') or upload is None:raise ToolError('先に現在のモデルを生成または読み込み、表・列が対応するExcelを選択してください。')
            WORK.mkdir(parents=True,exist_ok=True);edited=WORK/('customer-'+uuid4().hex[:8]+'.xlsx');edited.write_bytes(upload.getvalue());edited.chmod(0o600)
            old=load_bundle(st.session_state.baseline);require_customer_model(old);rows=read_review(edited,old);new=build_model(old['metadata'],old['config'],rows);diff=changes(old,new)
            destination=WORK/('updated-'+uuid4().hex[:8])
            with st.spinner('日本語名、削除フラグ、元モデルとの対応を検証しています…'):
                save_bundle(new,destination,previous=old,oac_url=oac_url)
            st.session_state.updated=str(destination);st.success(f'更新版を生成しました。変更した項目は{len(diff["items"])}件です。GitHubとOACにはまだ反映していません。')
        except Exception as err:error_message(err)
    if st.session_state.get('updated'):
        summary(st.session_state.updated,show_relationship_details=False);show_changes(read_json(Path(st.session_state.updated)/'changes.json'))
with tab3:
    st.subheader('3 GitHubへ同期 差分を確認してから実行')
    st.write('同期対象は3層のSMMLと生成ファイル管理情報のみです。Excel、Wallet、認証情報は送信しません。force pushや自動ブランチ切替は行いません。')
    default_repo=github.get('repo') or local_git.get('repo_path','')
    repo_path=Path(default_repo).expanduser() if default_repo else None
    repo=st.text_input('モデル用Git作業フォルダー 絶対パス',str((ROOT/repo_path).resolve()) if repo_path and not repo_path.is_absolute() else str(repo_path or ''))
    origin=st.text_input('GitHubリポジトリURL',github.get('origin',local_git.get('origin','')),placeholder='https://github.com/your-org/your-model.git')
    branch=st.text_input('現在のブランチ名',github.get('branch') or local_git.get('branch','main'))
    active_bundle=st.session_state.get('updated') or st.session_state.get('baseline')
    st.caption('同期元：'+(active_bundle or 'モデルはまだ生成されていません。'))
    if st.button('同期差分を確認 書込みなし'):
        try:
            if not active_bundle:raise ToolError('先にモデルを生成または読み込んでください。')
            plan=sync_plan(active_bundle,repo,branch,origin);st.session_state.sync_plan=plan
            st.write({'追加':len(plan['added']),'変更':len(plan['modified']),'削除':len(plan['removed'])})
            with st.expander('変更ファイル一覧'):
                st.json({k:plan[k] for k in ['added','modified','removed']})
        except Exception as err:error_message(err)
    confirm_key='git_confirm_'+digest([repo,origin,branch,active_bundle])
    confirm=st.checkbox('同期先と差分を確認しました。コミットとGitHubへのプッシュを許可します。',value=False,key=confirm_key)
    st.caption('この操作はGitHubへのコミットとプッシュを実行します。OACには自動デプロイしません。')
    github_token=st.text_input('GitHub Token',value=os.environ.get('GITHUB_TOKEN',''),type='password',key='github_token_input',help='既定値は起動時の本機環境変数GITHUB_TOKENから取得します。入力値は変更できます。画面で入力したTokenはセッション内でのみ使用し、設定ファイル・配布パッケージ・Gitには保存しません。')
    st.caption('Tokenの既定値は本機の環境変数GITHUB_TOKENから取得します。未設定の場合は、プッシュ時に入力してください。')
    st.caption('プッシュ前に非公開リポジトリであることを実際に検証します。公開・認証失敗・確認不能の場合は送信を拒否します。')
    if st.button('確認した内容をGitHubへプッシュ',disabled=not confirm):
        try:
            if not active_bundle:raise ToolError('先にモデルを生成してください。')
            if load_bundle(active_bundle)['metadata'].get('source')!='adb_dictionary_read_only':raise ToolError('オフラインサンプルは実環境へプッシュできません。「ADBから定義を取得」で新しいモデルを生成してください。')
            result=apply_sync(active_bundle,repo,branch,origin,confirmed=confirm,push=True,token=github_token or None)
            st.session_state.git_result=result;st.success('GitHubへのプッシュが完了しました。OACでのプルと検証は別途必要です。')
            st.caption(f'同期したファイル：{result["changed_files"]}件')
        except Exception as err:error_message(err)
with tab4:
    st.subheader('4 OACでプルして整合性を確認')
    st.info('この画面からOACのプル・検証・デプロイは実行しません。OAC側で操作してください。')
    if workspace_url and same_origin(oac_url,workspace_url):st.link_button('対象OACモデルを開く',workspace_url)
    elif workspace_url:st.warning('OAC URLとモデルURLの接続先が異なります。詳細設定で同じ環境を指定してください。')
    if oac_url:st.link_button('OACホームを開く',oac_url)
    st.write('Gitパネルでプル元を確認してプルし、「警告を含む」整合性チェックを行い、デプロイ前に詳細チェック（Advanced Check）も実施します。公開先・既存モデルへの影響・復旧手順を確認してから、権限を持つ担当者がデプロイしてください。')
    st.info('データ行の確認：物理レイヤー → データベース → スキーマ → 対象表をダブルクリック → プレビュー。Excelで変更した名前と除外項目は論理・プレゼンテーション両レイヤーで確認します。')
    st.caption('パスワードやTokenは設定ダウンロードとモデル出力に含めません。OACのGitプロファイルに保存する場合は管理者の運用ルールに従ってください。')
